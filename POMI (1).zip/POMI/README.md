# Pomodoro Timer

App Android (**Java** + Views XML/ViewBinding + Media3) con temporizador Pomodoro y reproductor de música.

## Cómo abrirlo
1. Android Studio Koala (2024.1) o superior, JDK 17.
2. `File > Open` y elegí la carpeta del proyecto. Android Studio descarga Gradle 8.7 y sincroniza solo.

## Estructura
- `MainActivity`: única Activity; aloja `PomodoroFragment` y `SettingsFragment`, que comparten los ViewModels de la Activity.
- `ui/`: fragments, `PlaylistBottomSheet` (lista de reproducción) y `TrackAdapter`.
- `ui/theme/`: paletas (`AppPalettes`), colores resueltos (`AppTheme`) y `ThemeApplier`.
- `viewmodel/`: `PomodoroViewModel`, `MusicViewModel`, `ThemeViewModel` (LiveData).
- `data/`: preferencias con SharedPreferences.
- `res/layout/`: layouts XML (se accede a ellos con ViewBinding).

## Logo
El ícono del launcher (adaptativo + clásico + redondo) está en `app/src/main/res/mipmap-*`.
Si lo querés cambiar: `New > Image Asset` en Android Studio.

## Timbre de los temporizadores
- `res/raw/timbre_1.mp3` suena al terminar cada sesión (si "Sonido al terminar" está activo en Ajustes).
- Para cambiarlo, reemplazá ese archivo conservando el nombre. En Android 8+ el sonido de un canal de
  notificación queda fijo al crearse: tras cambiarlo, desinstalá la app o cambiá el ID `CHANNEL_BELL`
  en `PomodoroNotifier.java`.
- Los archivos de `res/raw` cuyo nombre empieza con `timbre` no aparecen en la lista de música.

## Música
- Copiá tus MP3 en `app/src/main/res/raw/` (solo minúsculas, números y `_`, ej. `lofi_study.mp3`).
  Cada uno aparece automáticamente como pista predeterminada.
- También podés agregar archivos del teléfono con el botón "Agregar" de la lista.
- Al pasar a un descanso la música se pausa; al iniciar el trabajo se reanuda.

## Temas
En Ajustes > Apariencia: modo Sistema / Claro / Oscuro y 6 temas de color (Tomate, Océano, Bosque,
Lavanda, Atardecer, Grafito). Se aplican al instante y se recuerdan. Para agregar un tema, sumá una
entrada en `ui/theme/AppPalettes.java`.
