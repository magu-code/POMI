package com.ejemplo.pomodorotimer.data;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;

/**
 * Persistimos las URIs seleccionadas por el usuario, una por línea, para
 * conservar el orden de la lista (un Set no garantiza orden). Los metadatos se
 * re-leen al cargar con MetadataReader para no guardar información desactualizada.
 */
public class PlaylistPreferences {

    private static final String FILE = "playlist_prefs";
    private static final String USER_URIS = "user_uris_ordered";
    private static final String SEPARATOR = "\n";

    private final SharedPreferences prefs;

    public PlaylistPreferences(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public List<String> getUserUris() {
        return toList(prefs.getString(USER_URIS, null));
    }

    public synchronized void addUserUris(List<String> newUris) {
        List<String> current = getUserUris();
        for (String uri : newUris) {
            if (!current.contains(uri)) current.add(uri);
        }
        save(current);
    }

    public synchronized void removeUserUri(String uri) {
        List<String> current = getUserUris();
        current.remove(uri);
        save(current);
    }

    private void save(List<String> uris) {
        // (String.join necesita API 26 y el minSdk del proyecto es 24)
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < uris.size(); i++) {
            if (i > 0) sb.append(SEPARATOR);
            sb.append(uris.get(i));
        }
        prefs.edit().putString(USER_URIS, sb.toString()).apply();
    }

    private static List<String> toList(String raw) {
        List<String> result = new ArrayList<>();
        if (raw == null) return result;
        for (String part : raw.split(SEPARATOR)) {
            if (!part.trim().isEmpty()) result.add(part);
        }
        return result;
    }
}
