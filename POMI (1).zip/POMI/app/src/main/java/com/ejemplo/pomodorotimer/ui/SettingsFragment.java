package com.ejemplo.pomodorotimer.ui;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.graphics.ColorUtils;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.ejemplo.pomodorotimer.R;
import com.ejemplo.pomodorotimer.data.PomodoroPreferences;
import com.ejemplo.pomodorotimer.databinding.FragmentSettingsBinding;
import com.ejemplo.pomodorotimer.databinding.ItemDurationBinding;
import com.ejemplo.pomodorotimer.databinding.ItemPaletteBinding;
import com.ejemplo.pomodorotimer.databinding.ItemSwitchRowBinding;
import com.ejemplo.pomodorotimer.model.SessionType;
import com.ejemplo.pomodorotimer.model.ThemeMode;
import com.ejemplo.pomodorotimer.model.ThemeSettings;
import com.ejemplo.pomodorotimer.ui.theme.AppPalette;
import com.ejemplo.pomodorotimer.ui.theme.AppPalettes;
import com.ejemplo.pomodorotimer.ui.theme.AppTheme;
import com.ejemplo.pomodorotimer.ui.theme.ThemeApplier;
import com.ejemplo.pomodorotimer.viewmodel.PomodoroViewModel;
import com.ejemplo.pomodorotimer.viewmodel.ThemeViewModel;

import java.util.ArrayList;
import java.util.List;
import java.util.function.IntConsumer;

public class SettingsFragment extends Fragment {

    private static final String KEY_WORK = "work_min";
    private static final String KEY_SHORT = "short_min";
    private static final String KEY_LONG = "long_min";

    private FragmentSettingsBinding b;
    private PomodoroViewModel viewModel;
    private ThemeViewModel themeViewModel;
    private PomodoroPreferences prefs;

    private AppTheme theme;
    private ThemeSettings themeSettings = new ThemeSettings();

    private int workMin;
    private int shortMin;
    private int longMin;

    private final List<ItemDurationBinding> sliderRows = new ArrayList<>();
    private final List<ItemSwitchRowBinding> switchRows = new ArrayList<>();
    private final List<TextView> modeViews = new ArrayList<>();

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new PomodoroPreferences(requireContext());

        // Los sliders solo se guardan al tocar "Guardar", pero sobreviven a rotaciones
        // y a la recreación por cambio de modo claro/oscuro.
        workMin = savedInstanceState != null ? savedInstanceState.getInt(KEY_WORK) : prefs.getWorkMinutes();
        shortMin = savedInstanceState != null ? savedInstanceState.getInt(KEY_SHORT) : prefs.getShortBreakMinutes();
        longMin = savedInstanceState != null ? savedInstanceState.getInt(KEY_LONG) : prefs.getLongBreakMinutes();
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(KEY_WORK, workMin);
        outState.putInt(KEY_SHORT, shortMin);
        outState.putInt(KEY_LONG, longMin);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        b = FragmentSettingsBinding.inflate(inflater, container, false);
        return b.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ViewModelProvider provider = new ViewModelProvider(requireActivity());
        viewModel = provider.get(PomodoroViewModel.class);
        themeViewModel = provider.get(ThemeViewModel.class);

        setupInsets();

        b.btnBack.setOnClickListener(v -> goBack());

        buildModeSelector();

        addSliderRow(SessionType.WORK.getLabel(), workMin, 5, 60, v -> workMin = v);
        addSliderRow(SessionType.SHORT_BREAK.getLabel(), shortMin, 1, 30, v -> shortMin = v);
        addSliderRow(SessionType.LONG_BREAK.getLabel(), longMin, 5, 45, v -> longMin = v);

        addSwitchRow(getString(R.string.sound_on_finish), prefs.isSoundEnabled(),
                checked -> prefs.setSoundEnabled(checked));
        addSwitchRow(getString(R.string.vibration_on_finish), prefs.isVibrationEnabled(),
                checked -> prefs.setVibrationEnabled(checked));

        b.btnSave.setOnClickListener(v -> {
            viewModel.updateDurations(workMin, shortMin, longMin);
            goBack();
        });

        themeViewModel.getSettings().observe(getViewLifecycleOwner(), settings -> {
            themeSettings = settings;
            theme = AppTheme.from(requireContext(), settings);
            applyTheme();
        });
    }

    @Override
    public void onDestroyView() {
        sliderRows.clear();
        switchRows.clear();
        modeViews.clear();
        b = null;
        super.onDestroyView();
    }

    private void goBack() {
        getParentFragmentManager().popBackStack();
    }

    private void setupInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(b.getRoot(), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            v.setPadding(bars.left, 0, bars.right, 0);
            b.appBar.setPadding(0, bars.top, 0, 0);
            b.scroll.setPadding(0, 0, 0, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
        ViewCompat.requestApplyInsets(b.getRoot());
    }

    // ---------------------------------------------------------------- filas

    private void addSliderRow(String label, int value, int min, int max, IntConsumer onChange) {
        ItemDurationBinding row = ItemDurationBinding.inflate(getLayoutInflater(), b.durationsContainer, true);
        sliderRows.add(row);

        row.label.setText(label);
        row.value.setText(getString(R.string.minutes_format, value));

        row.slider.setValueFrom(min);
        row.slider.setValueTo(max);
        row.slider.setStepSize(1f);
        row.slider.setValue(Math.max(min, Math.min(max, value)));
        row.slider.addOnChangeListener((slider, newValue, fromUser) -> {
            int minutes = Math.round(newValue);
            row.value.setText(getString(R.string.minutes_format, minutes));
            onChange.accept(minutes);
        });
    }

    private interface BooleanConsumer {
        void accept(boolean value);
    }

    private void addSwitchRow(String label, boolean checked, BooleanConsumer onChange) {
        ItemSwitchRowBinding row = ItemSwitchRowBinding.inflate(getLayoutInflater(), b.switchesContainer, true);
        switchRows.add(row);

        row.label.setText(label);
        row.switchView.setChecked(checked);
        // Se guarda al instante, igual que antes
        row.switchView.setOnCheckedChangeListener((button, isChecked) -> onChange.accept(isChecked));
    }

    // ---------------------------------------------------------------- selector de modo

    private void buildModeSelector() {
        b.modeSelector.removeAllViews();
        modeViews.clear();

        ThemeMode[] modes = ThemeMode.values();
        for (int i = 0; i < modes.length; i++) {
            ThemeMode mode = modes[i];

            TextView tv = new TextView(requireContext());
            tv.setText(mode.getLabel());
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            tv.setGravity(Gravity.CENTER);
            tv.setPadding(0, UiUtils.dp(requireContext(), 12), 0, UiUtils.dp(requireContext(), 12));
            tv.setClickable(true);
            tv.setFocusable(true);
            tv.setForeground(UiUtils.selectableForeground(requireContext()));
            tv.setOnClickListener(v -> themeViewModel.setMode(mode));

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i > 0) lp.setMarginStart(UiUtils.dp(requireContext(), 8));
            b.modeSelector.addView(tv, lp);
            modeViews.add(tv);
        }
    }

    private void updateModeSelector() {
        ThemeMode[] modes = ThemeMode.values();
        for (int i = 0; i < modeViews.size(); i++) {
            TextView tv = modeViews.get(i);
            boolean isSelected = modes[i] == themeSettings.mode;
            UiUtils.setShapedBackground(tv, UiUtils.pill(isSelected ? theme.primary : theme.surfaceVariant));
            tv.setTextColor(isSelected ? theme.onPrimary : theme.onSurfaceVariant);
            tv.setTypeface(null, isSelected ? Typeface.BOLD : Typeface.NORMAL);
        }
    }

    // ---------------------------------------------------------------- paletas

    private void bindPalettes() {
        b.paletteContainer.removeAllViews();
        List<AppPalette> all = AppPalettes.ALL;
        int gap = UiUtils.dp(requireContext(), 8);

        for (int i = 0; i < all.size(); i += 2) {
            LinearLayout row = new LinearLayout(requireContext());
            row.setOrientation(LinearLayout.HORIZONTAL);

            for (int j = i; j < Math.min(i + 2, all.size()); j++) {
                AppPalette palette = all.get(j);
                ItemPaletteBinding card = ItemPaletteBinding.inflate(getLayoutInflater(), row, false);

                boolean isSelected = palette.id.equals(themeSettings.paletteId);
                int strokeColor = isSelected
                        ? palette.colors.work
                        : UiUtils.withAlpha(theme.onSurfaceVariant, 0.2f);
                int strokePx = UiUtils.dp(requireContext(), isSelected ? 2 : 1);
                UiUtils.setShapedBackground(card.card, UiUtils.roundRectStroke(
                        theme.surfaceVariant, UiUtils.dp(requireContext(), 16), strokeColor, strokePx));

                card.paletteName.setText(palette.label);
                card.paletteName.setTextColor(theme.onSurface);
                card.paletteName.setTypeface(null, isSelected ? Typeface.BOLD : Typeface.NORMAL);

                card.dotWork.setBackground(UiUtils.oval(palette.colors.work));
                card.dotShort.setBackground(UiUtils.oval(palette.colors.shortBreak));
                card.dotLong.setBackground(UiUtils.oval(palette.colors.longBreak));

                card.card.setOnClickListener(v -> themeViewModel.setPalette(palette.id));

                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                if (j > i) lp.setMarginStart(gap);
                row.addView(card.getRoot(), lp);
            }
            // Si la fila queda impar, se rellena para que las tarjetas mantengan su ancho
            if (all.size() - i == 1) {
                View filler = new View(requireContext());
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 1, 1f);
                lp.setMarginStart(gap);
                row.addView(filler, lp);
            }

            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            if (i > 0) rowLp.topMargin = gap;
            b.paletteContainer.addView(row, rowLp);
        }
    }

    // ---------------------------------------------------------------- tema

    private void applyTheme() {
        ThemeApplier.apply(b.getRoot(), theme);

        updateModeSelector();
        bindPalettes();

        ColorStateList primary = ColorStateList.valueOf(theme.primary);
        ColorStateList inactiveTrack = ColorStateList.valueOf(
                ColorUtils.blendARGB(theme.background, theme.onSurfaceVariant, 0.3f));
        ColorStateList halo = ColorStateList.valueOf(UiUtils.withAlpha(theme.primary, 0.2f));
        for (ItemDurationBinding row : sliderRows) {
            row.slider.setThumbTintList(primary);
            row.slider.setTrackActiveTintList(primary);
            row.slider.setTrackInactiveTintList(inactiveTrack);
            row.slider.setHaloTintList(halo);
        }

        int[][] states = {{android.R.attr.state_checked}, {}};
        ColorStateList thumb = new ColorStateList(states, new int[]{theme.onPrimary, theme.onSurfaceVariant});
        ColorStateList track = new ColorStateList(states, new int[]{theme.primary, theme.surfaceVariant});
        ColorStateList outline = new ColorStateList(states, new int[]{Color.TRANSPARENT, theme.onSurfaceVariant});
        for (ItemSwitchRowBinding row : switchRows) {
            row.switchView.setThumbTintList(thumb);
            row.switchView.setTrackTintList(track);
            row.switchView.setTrackDecorationTintList(outline);
        }

        b.btnSave.setBackgroundTintList(primary);
        b.btnSave.setTextColor(theme.onPrimary);
    }
}
