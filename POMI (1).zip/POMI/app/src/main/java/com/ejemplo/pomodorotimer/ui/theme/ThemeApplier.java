package com.ejemplo.pomodorotimer.ui.theme;

import android.content.res.ColorStateList;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.widget.ImageViewCompat;

/**
 * Pinta con los colores del tema todas las vistas marcadas con android:tag en el XML.
 * Como la paleta se puede cambiar en caliente, los colores no van fijos en los layouts:
 *
 *   bg, surface, surfaceVariant  -> color de fondo de la vista
 *   text, textVariant, textPrimary -> color de texto (onSurface, onSurfaceVariant, primary)
 *   icon, iconVariant            -> tinte de un ImageView / ImageButton
 *
 * Los fondos con forma (círculos, píldoras, tarjetas) se pintan por código con UiUtils.
 */
public final class ThemeApplier {

    public static final String BG = "bg";
    public static final String SURFACE = "surface";
    public static final String SURFACE_VARIANT = "surfaceVariant";
    public static final String TEXT = "text";
    public static final String TEXT_VARIANT = "textVariant";
    public static final String TEXT_PRIMARY = "textPrimary";
    public static final String ICON = "icon";
    public static final String ICON_VARIANT = "iconVariant";

    private ThemeApplier() { }

    public static void apply(View view, AppTheme t) {
        Object tag = view.getTag();
        if (tag instanceof String) applyTag(view, (String) tag, t);

        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                apply(group.getChildAt(i), t);
            }
        }
    }

    private static void applyTag(View view, String tag, AppTheme t) {
        switch (tag) {
            case BG:
                view.setBackgroundColor(t.background);
                break;
            case SURFACE:
                view.setBackgroundColor(t.surface);
                break;
            case SURFACE_VARIANT:
                view.setBackgroundColor(t.surfaceVariant);
                break;
            case TEXT:
                setTextColor(view, t.onSurface);
                break;
            case TEXT_VARIANT:
                setTextColor(view, t.onSurfaceVariant);
                break;
            case TEXT_PRIMARY:
                setTextColor(view, t.primary);
                break;
            case ICON:
                setTint(view, t.onSurface);
                break;
            case ICON_VARIANT:
                setTint(view, t.onSurfaceVariant);
                break;
            default:
                break;
        }
    }

    private static void setTextColor(View view, int color) {
        if (view instanceof TextView) ((TextView) view).setTextColor(color);
    }

    private static void setTint(View view, int color) {
        if (view instanceof ImageView) {
            ImageViewCompat.setImageTintList((ImageView) view, ColorStateList.valueOf(color));
        }
    }
}
