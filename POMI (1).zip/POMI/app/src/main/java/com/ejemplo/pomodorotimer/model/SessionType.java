package com.ejemplo.pomodorotimer.model;

public enum SessionType {
    WORK("Trabajo"),
    SHORT_BREAK("Descanso corto"),
    LONG_BREAK("Descanso largo");

    private final String label;

    SessionType(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
