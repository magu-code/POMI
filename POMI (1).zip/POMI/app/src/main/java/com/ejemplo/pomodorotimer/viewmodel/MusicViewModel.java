package com.ejemplo.pomodorotimer.viewmodel;

import android.app.Application;
import android.content.ComponentName;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Player;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;

import com.ejemplo.pomodorotimer.R;
import com.ejemplo.pomodorotimer.data.PlaylistPreferences;
import com.ejemplo.pomodorotimer.model.MusicState;
import com.ejemplo.pomodorotimer.model.SessionType;
import com.ejemplo.pomodorotimer.model.Track;
import com.ejemplo.pomodorotimer.service.PlaybackService;
import com.ejemplo.pomodorotimer.util.MetadataReader;
import com.google.common.util.concurrent.ListenableFuture;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.UnaryOperator;

public class MusicViewModel extends AndroidViewModel {

    private final Application context;
    private final PlaylistPreferences playlistPrefs;

    private final MutableLiveData<MusicState> state = new MutableLiveData<>(new MusicState());

    /** Hilo de fondo para leer metadatos (MediaMetadataRetriever es lento) */
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    private ListenableFuture<MediaController> controllerFuture;
    private MediaController controller;
    private Runnable pendingAction;
    private boolean cleared = false;

    private final Player.Listener listener = new Player.Listener() {
        @Override
        public void onIsPlayingChanged(boolean isPlaying) {
            update(s -> s.withPlaying(isPlaying));
        }

        @Override
        public void onMediaItemTransition(@Nullable MediaItem mediaItem, int reason) {
            String id = mediaItem != null ? mediaItem.mediaId : null;
            update(s -> {
                int idx = indexOfId(s.playlist, id);
                return s.withCurrent(idx, idx >= 0 ? s.playlist.get(idx) : null);
            });
        }

        @Override
        public void onShuffleModeEnabledChanged(boolean shuffleModeEnabled) {
            update(s -> s.withShuffle(shuffleModeEnabled));
        }

        @Override
        public void onRepeatModeChanged(int repeatMode) {
            update(s -> s.withRepeat(repeatMode));
        }
    };

    public MusicViewModel(@NonNull Application app) {
        super(app);
        context = app;
        playlistPrefs = new PlaylistPreferences(app);

        io.execute(() -> {
            List<Track> full = new ArrayList<>(buildDefaultPlaylist());
            full.addAll(loadPersistedUserTracks());
            main.post(() -> {
                if (cleared) return;
                update(s -> s.withPlaylist(full)
                        .withCurrent(full.isEmpty() ? -1 : 0, full.isEmpty() ? null : full.get(0)));
                connectToService();
            });
        });
    }

    public LiveData<MusicState> getState() {
        return state;
    }

    private MusicState current() {
        return state.getValue();
    }

    /** Solo se llama desde el hilo principal */
    private void update(UnaryOperator<MusicState> change) {
        state.setValue(change.apply(current()));
    }

    private static int indexOfId(List<Track> list, @Nullable String id) {
        if (id == null) return -1;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id.equals(id)) return i;
        }
        return -1;
    }

    /**
     * Toda la música que el usuario pegue en res/raw pasa a ser una pista predeterminada.
     * Se descubre por reflexión sobre R.raw porque esa clase NO existe mientras la
     * carpeta raw esté vacía: referenciar R.raw.lofi_study directamente rompía la
     * compilación si faltaba algún mp3.
     */
    private List<Track> buildDefaultPlaylist() {
        Class<?> rawClass;
        try {
            rawClass = Class.forName(R.class.getName() + "$raw");
        } catch (ClassNotFoundException e) {
            return Collections.emptyList();
        }

        List<Field> fields = new ArrayList<>();
        for (Field f : rawClass.getFields()) {
            // Los sonidos "timbre_*" son de las alarmas, no forman parte de la lista de música
            if (f.getType() == int.class
                    && Modifier.isStatic(f.getModifiers())
                    && !f.getName().startsWith("timbre")) {
                fields.add(f);
            }
        }
        Collections.sort(fields, Comparator.comparing(Field::getName));

        List<Track> tracks = new ArrayList<>();
        for (Field field : fields) {
            int resId;
            try {
                resId = field.getInt(null);
            } catch (Exception e) {
                continue;
            }
            tracks.add(MetadataReader.read(
                    context,
                    rawUri(resId),
                    prettyName(field.getName()),
                    "Pomodoro Radio",
                    "default_" + field.getName(),
                    true));
        }
        return tracks;
    }

    private String prettyName(String resName) {
        StringBuilder sb = new StringBuilder();
        for (String part : resName.split("_")) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }

    private List<Track> loadPersistedUserTracks() {
        List<Track> tracks = new ArrayList<>();
        for (String uriStr : playlistPrefs.getUserUris()) {
            try {
                tracks.add(MetadataReader.read(context, Uri.parse(uriStr)));
            } catch (Exception ignored) { }
        }
        return tracks;
    }

    private Uri rawUri(int resId) {
        return Uri.parse("android.resource://" + context.getPackageName() + "/" + resId);
    }

    private void connectToService() {
        SessionToken token = new SessionToken(context, new ComponentName(context, PlaybackService.class));
        ListenableFuture<MediaController> future = new MediaController.Builder(context, token).buildAsync();
        controllerFuture = future;
        future.addListener(() -> {
            try {
                MediaController c = future.get();
                if (cleared) {
                    c.release();
                    return;
                }
                controller = c;
                c.addListener(listener);
                syncPlayerWithPlaylist(c);
                update(s -> s.withControllerReady(true));
                if (pendingAction != null) {
                    pendingAction.run();
                    pendingAction = null;
                }
            } catch (Exception ignored) { }
        }, ContextCompat.getMainExecutor(context));
    }

    /**
     * Si el servicio ya tenía la misma lista cargada (p. ej. la app se reabrió mientras
     * sonaba música) se conserva la reproducción; si no, se carga la lista completa.
     */
    private void syncPlayerWithPlaylist(MediaController c) {
        List<Track> playlist = current().playlist;
        if (playlist.isEmpty()) return;

        boolean shuffle = c.getShuffleModeEnabled();
        int repeat = c.getRepeatMode();

        List<String> playerIds = new ArrayList<>();
        for (int i = 0; i < c.getMediaItemCount(); i++) {
            playerIds.add(c.getMediaItemAt(i).mediaId);
        }
        List<String> playlistIds = new ArrayList<>();
        for (Track t : playlist) playlistIds.add(t.id);

        if (playerIds.equals(playlistIds)) {
            MediaItem item = c.getCurrentMediaItem();
            int idx = Math.max(0, indexOfId(playlist, item != null ? item.mediaId : null));
            boolean playing = c.isPlaying();
            update(s -> s.withPlaying(playing).withCurrent(idx, playlist.get(idx))
                    .withShuffle(shuffle).withRepeat(repeat));
        } else {
            c.setMediaItems(toMediaItems(playlist));
            c.prepare();
            update(s -> s.withShuffle(shuffle).withRepeat(repeat));
        }
    }

    private static List<MediaItem> toMediaItems(List<Track> tracks) {
        List<MediaItem> items = new ArrayList<>();
        for (Track t : tracks) items.add(toMediaItem(t));
        return items;
    }

    private static MediaItem toMediaItem(Track track) {
        MediaMetadata.Builder metadata = new MediaMetadata.Builder()
                .setTitle(track.title)
                .setArtist(track.artist)
                .setAlbumTitle(track.album);
        if (track.artworkUri != null) {
            metadata.setArtworkUri(Uri.parse(track.artworkUri));
        }

        return new MediaItem.Builder()
                .setUri(track.uri)
                .setMediaId(track.id)
                .setMediaMetadata(metadata.build())
                .build();
    }

    private void runWhenReady(Runnable action) {
        if (controller != null) action.run();
        else pendingAction = action;
    }

    public void addUserTracks(List<Uri> uris) {
        io.execute(() -> {
            List<Track> newTracks = new ArrayList<>();
            for (Uri uri : uris) newTracks.add(MetadataReader.read(context, uri));

            main.post(() -> {
                if (cleared) return;

                Set<String> existing = new HashSet<>();
                for (Track t : current().playlist) existing.add(t.id);
                List<Track> filtered = new ArrayList<>();
                for (Track t : newTracks) {
                    if (existing.add(t.id)) filtered.add(t);
                }
                if (filtered.isEmpty()) return;

                List<Track> updated = new ArrayList<>(current().playlist);
                updated.addAll(filtered);
                update(s -> s.withPlaylist(updated));

                // Solo se agregan las pistas nuevas: no se reinicia lo que está sonando
                if (controller != null) {
                    controller.addMediaItems(toMediaItems(filtered));
                    if (controller.getPlaybackState() == Player.STATE_IDLE) controller.prepare();
                }

                List<String> ids = new ArrayList<>();
                for (Track t : filtered) ids.add(t.id);
                playlistPrefs.addUserUris(ids);
            });
        });
    }

    public void removeTrack(Track track) {
        int index = indexOfId(current().playlist, track.id);
        if (index < 0) return;

        List<Track> updated = new ArrayList<>(current().playlist);
        updated.remove(index);
        update(s -> {
            // Si se borró una pista anterior a la actual, el índice se corre.
            // Si se borró la pista actual, no conservar una referencia obsoleta.
            String currentId = s.currentTrack != null ? s.currentTrack.id : null;
            int newIndex = indexOfId(updated, currentId);
            Track newCurrent = newIndex >= 0 ? updated.get(newIndex) : null;
            return s.withPlaylist(updated).withCurrent(newIndex, newCurrent);
        });

        if (controller != null) controller.removeMediaItem(index);
        if (!track.isDefault) playlistPrefs.removeUserUri(track.id);
    }

    public void playTrack(Track track) {
        runWhenReady(() -> {
            int idx = indexOfId(current().playlist, track.id);
            if (idx >= 0) {
                controller.seekTo(idx, 0L);
                controller.play();
            }
        });
    }

    public void togglePlayPause() {
        runWhenReady(() -> {
            if (controller.isPlaying()) controller.pause();
            else controller.play();
        });
    }

    public void next() {
        runWhenReady(() -> {
            controller.seekToNextMediaItem();
            controller.play();
        });
    }

    public void previous() {
        runWhenReady(() -> {
            controller.seekToPreviousMediaItem();
            controller.play();
        });
    }

    public void seekTo(long positionMs) {
        runWhenReady(() -> controller.seekTo(positionMs));
    }

    public void toggleShuffle() {
        runWhenReady(() -> {
            boolean enabled = !controller.getShuffleModeEnabled();
            controller.setShuffleModeEnabled(enabled);
        });
    }

    public void cycleRepeatMode() {
        runWhenReady(() -> {
            int mode = controller.getRepeatMode();
            int next;
            if (mode == Player.REPEAT_MODE_OFF) next = Player.REPEAT_MODE_ALL;
            else if (mode == Player.REPEAT_MODE_ALL) next = Player.REPEAT_MODE_ONE;
            else next = Player.REPEAT_MODE_OFF;
            controller.setRepeatMode(next);
        });
    }

    /** Integración Pomodoro: reanuda la música al trabajar y la pausa en los descansos */
    public void onSessionChanged(SessionType type) {
        runWhenReady(() -> {
            if (type == SessionType.WORK) {
                if (!controller.isPlaying()) controller.play();
            } else {
                controller.pause();
            }
        });
    }

    @Override
    protected void onCleared() {
        cleared = true;
        io.shutdown();
        if (controller != null) {
            controller.removeListener(listener);
        }
        if (controllerFuture != null) {
            MediaController.releaseFuture(controllerFuture);
        }
        controller = null;
        super.onCleared();
    }
}
