package com.ejemplo.pomodorotimer;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.lifecycle.ViewModelProvider;

import com.ejemplo.pomodorotimer.ui.PomodoroFragment;
import com.ejemplo.pomodorotimer.ui.theme.AppTheme;
import com.ejemplo.pomodorotimer.viewmodel.ThemeViewModel;

/**
 * Única Activity. Aloja PomodoroFragment y SettingsFragment, que comparten los ViewModels
 * de la Activity (PomodoroViewModel, MusicViewModel y ThemeViewModel).
 */
public class MainActivity extends AppCompatActivity {

    private final ActivityResultLauncher<String> requestNotif =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> { });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            boolean granted = ContextCompat.checkSelfPermission(
                    this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
            if (!granted) requestNotif.launch(Manifest.permission.POST_NOTIFICATIONS);
        }

        // Fondo de la ventana e íconos de las barras del sistema según el tema elegido. Si el
        // modo elegido difiere del del sistema, los íconos deben contrastar con NUESTRO fondo.
        ThemeViewModel themeVm = new ViewModelProvider(this).get(ThemeViewModel.class);
        themeVm.getSettings().observe(this, settings -> {
            AppTheme theme = AppTheme.from(this, settings);
            Window window = getWindow();
            View decor = window.getDecorView();
            decor.setBackgroundColor(theme.background);

            WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(window, decor);
            controller.setAppearanceLightStatusBars(!theme.dark);
            controller.setAppearanceLightNavigationBars(!theme.dark);
        });

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .setReorderingAllowed(true)
                    .replace(R.id.fragment_container, new PomodoroFragment())
                    .commit();
        }
    }
}
