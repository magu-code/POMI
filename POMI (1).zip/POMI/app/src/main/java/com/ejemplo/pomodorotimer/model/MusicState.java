package com.ejemplo.pomodorotimer.model;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Estado inmutable del reproductor. Los métodos with... devuelven una copia modificada. */
public final class MusicState {

    public final List<Track> playlist;
    public final int currentIndex;
    public final boolean isPlaying;
    @Nullable
    public final Track currentTrack;
    public final boolean controllerReady;
    public final boolean shuffleEnabled;
    public final int repeatMode; // Player.REPEAT_MODE_OFF, REPEAT_MODE_ONE, REPEAT_MODE_ALL

    public MusicState() {
        this(Collections.<Track>emptyList(), -1, false, null, false, false, 2);
    }

    public MusicState(List<Track> playlist, int currentIndex, boolean isPlaying,
                      @Nullable Track currentTrack, boolean controllerReady,
                      boolean shuffleEnabled, int repeatMode) {
        this.playlist = Collections.unmodifiableList(new ArrayList<>(playlist));
        this.currentIndex = currentIndex;
        this.isPlaying = isPlaying;
        this.currentTrack = currentTrack;
        this.controllerReady = controllerReady;
        this.shuffleEnabled = shuffleEnabled;
        this.repeatMode = repeatMode;
    }

    public MusicState withPlaylist(List<Track> newPlaylist) {
        return new MusicState(newPlaylist, currentIndex, isPlaying, currentTrack, controllerReady, shuffleEnabled, repeatMode);
    }

    public MusicState withPlaying(boolean playing) {
        return new MusicState(playlist, currentIndex, playing, currentTrack, controllerReady, shuffleEnabled, repeatMode);
    }

    public MusicState withCurrent(int index, @Nullable Track track) {
        return new MusicState(playlist, index, isPlaying, track, controllerReady, shuffleEnabled, repeatMode);
    }

    public MusicState withControllerReady(boolean ready) {
        return new MusicState(playlist, currentIndex, isPlaying, currentTrack, ready, shuffleEnabled, repeatMode);
    }

    public MusicState withShuffle(boolean shuffle) {
        return new MusicState(playlist, currentIndex, isPlaying, currentTrack, controllerReady, shuffle, repeatMode);
    }

    public MusicState withRepeat(int repeat) {
        return new MusicState(playlist, currentIndex, isPlaying, currentTrack, controllerReady, shuffleEnabled, repeat);
    }
}
