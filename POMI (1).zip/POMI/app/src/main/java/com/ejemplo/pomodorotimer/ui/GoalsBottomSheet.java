package com.ejemplo.pomodorotimer.ui;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.res.ColorStateList;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ejemplo.pomodorotimer.R;
import com.ejemplo.pomodorotimer.data.GoalsPreferences;
import com.ejemplo.pomodorotimer.data.PomodoroDatabaseHelper;
import com.ejemplo.pomodorotimer.databinding.DialogCreateGoalBinding;
import com.ejemplo.pomodorotimer.databinding.SheetGoalsBinding;
import com.ejemplo.pomodorotimer.model.Goal;
import com.ejemplo.pomodorotimer.ui.theme.AppTheme;
import com.ejemplo.pomodorotimer.ui.theme.ThemeApplier;
import com.ejemplo.pomodorotimer.viewmodel.ThemeViewModel;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import androidx.lifecycle.ViewModelProvider;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class GoalsBottomSheet extends BottomSheetDialogFragment {

    private static final String ARG_ACCENT = "accent";
    private int accent;

    public static GoalsBottomSheet newInstance(int accent) {
        GoalsBottomSheet sheet = new GoalsBottomSheet();
        Bundle args = new Bundle();
        args.putInt(ARG_ACCENT, accent);
        sheet.setArguments(args);
        return sheet;
    }

    private SheetGoalsBinding b;
    private GoalsPreferences prefs;
    private GoalAdapter adapter;
    private AppTheme theme;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        b = SheetGoalsBinding.inflate(inflater, container, false);
        return b.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        accent = requireArguments().getInt(ARG_ACCENT);
        ThemeViewModel themeViewModel = new ViewModelProvider(requireActivity()).get(ThemeViewModel.class);
        theme = AppTheme.from(requireContext(), themeViewModel.getSettings().getValue());
        prefs = new GoalsPreferences(requireContext());

        adapter = new GoalAdapter(new GoalAdapter.Listener() {
            @Override
            public void onGoalCheck(Goal goal, boolean checked) {
                prefs.setGoalCompleted(goal.id, checked);
                loadGoals();
                if (checked) {
                    try {
                        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                        new PomodoroDatabaseHelper(requireContext()).addRecord(today, goal.durationMinutes, "meta");
                    } catch (Exception ignored) { }
                    showMotivationalDialog();
                } else if (goal.isCompleted) {
                    removeLastMetaRecord();
                }
            }

            @Override
            public void onDeleteGoal(Goal goal) {
                boolean wasCompleted = goal.isCompleted;
                prefs.removeGoal(goal.id);
                loadGoals();
                if (wasCompleted) {
                    removeLastMetaRecord();
                }
            }
        });
        adapter.setTheme(theme, accent);
        b.goalList.setLayoutManager(new LinearLayoutManager(requireContext()));
        b.goalList.setAdapter(adapter);

        ThemeApplier.apply(b.getRoot(), theme);
        b.btnAddGoal.setBackgroundTintList(ColorStateList.valueOf(theme.surfaceVariant));
        b.btnAddGoal.setTextColor(theme.onSurface);
        b.btnAddGoal.setIconTint(ColorStateList.valueOf(theme.onSurface));
        b.btnAddGoal.setOnClickListener(v -> showCreateGoalDialog());

        b.btnClearAllGoals.setTextColor(theme.onSurfaceVariant);
        b.btnClearAllGoals.setOnClickListener(v -> {
            new AlertDialog.Builder(requireContext())
                    .setTitle("Borrar metas")
                    .setMessage("¿Estás seguro de que deseas borrar todas las metas?")
                    .setPositiveButton("Borrar", (dialog, which) -> {
                        prefs.saveGoals(new ArrayList<>());
                        loadGoals();
                    })
                    .setNegativeButton(android.R.string.cancel, null)
                    .show();
        });

        loadGoals();
    }

    private void removeLastMetaRecord() {
        try {
            SQLiteDatabase db = new PomodoroDatabaseHelper(requireContext()).getWritableDatabase();
            db.execSQL("DELETE FROM " + PomodoroDatabaseHelper.TABLE_STATS + 
                    " WHERE " + PomodoroDatabaseHelper.COLUMN_TYPE + " = 'meta' " +
                    " AND " + PomodoroDatabaseHelper.COLUMN_ID + " = (SELECT MAX(" + PomodoroDatabaseHelper.COLUMN_ID + ") FROM " + PomodoroDatabaseHelper.TABLE_STATS + 
                    " WHERE " + PomodoroDatabaseHelper.COLUMN_TYPE + " = 'meta')");
            db.close();
        } catch (Exception ignored) { }
    }

    private void loadGoals() {
        List<Goal> goals = prefs.getGoals();
        adapter.submit(goals);
    }

    private void showCreateGoalDialog() {
        DialogCreateGoalBinding dialogBinding = DialogCreateGoalBinding.inflate(getLayoutInflater());
        new AlertDialog.Builder(requireContext())
                .setView(dialogBinding.getRoot())
                .setPositiveButton(R.string.save, (dialog, which) -> {
                    String name = dialogBinding.etGoalName.getText().toString().trim();
                    String durationStr = dialogBinding.etGoalDuration.getText().toString().trim();
                    if (!name.isEmpty()) {
                        int duration = 25;
                        try {
                            duration = Integer.parseInt(durationStr);
                        } catch (NumberFormatException ignored) { }
                        prefs.addGoal(name, duration);
                        loadGoals();
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void showMotivationalDialog() {
        new AlertDialog.Builder(requireContext())
                .setTitle("¡Meta cumplida! 🎉")
                .setMessage(R.string.goal_congrats)
                .setPositiveButton(android.R.string.ok, null)
                .show();
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog instanceof BottomSheetDialog && theme != null) {
            BottomSheetDialog sheetDialog = (BottomSheetDialog) dialog;
            FrameLayout sheet = sheetDialog.findViewById(com.google.android.material.R.id.design_bottom_sheet);
            if (sheet != null) {
                sheet.setBackgroundTintList(ColorStateList.valueOf(theme.surface));
            }
            BottomSheetBehavior<FrameLayout> behavior = sheetDialog.getBehavior();
            behavior.setSkipCollapsed(true);
            behavior.setState(BottomSheetBehavior.STATE_EXPANDED);
        }
    }

    @Override
    public void onDestroyView() {
        b = null;
        super.onDestroyView();
    }
}
