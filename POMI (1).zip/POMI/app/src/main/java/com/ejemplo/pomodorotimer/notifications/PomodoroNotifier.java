package com.ejemplo.pomodorotimer.notifications;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.ejemplo.pomodorotimer.MainActivity;
import com.ejemplo.pomodorotimer.R;

public final class PomodoroNotifier {

    // Desde Android 8 el sonido lo define el canal y no se puede cambiar una vez creado,
    // por eso el canal con el timbre propio tiene un ID nuevo. Hay un segundo canal
    // silencioso para respetar el ajuste "Sonido".
    private static final String CHANNEL_BELL = "pomodoro_sessions_bell";
    private static final String CHANNEL_SILENT = "pomodoro_sessions_silent_v2";
    private static final int NOTIFICATION_ID = 1001;

    private static final AudioAttributes BELL_ATTRIBUTES = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build();

    private PomodoroNotifier() { }

    /** Timbre predeterminado: res/raw/timbre_1.mp3 */
    private static Uri bellUri(Context context) {
        return Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.timbre_1);
    }

    public static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;

        NotificationManager manager = context.getSystemService(NotificationManager.class);

        // Canales de versiones anteriores (sonido del sistema)
        manager.deleteNotificationChannel("pomodoro_sessions");
        manager.deleteNotificationChannel("pomodoro_sessions_silent");

        NotificationChannel bell = new NotificationChannel(
                CHANNEL_BELL, "Sesiones Pomodoro", NotificationManager.IMPORTANCE_HIGH);
        bell.setDescription("Notificaciones con timbre al terminar sesiones");
        bell.setSound(bellUri(context), BELL_ATTRIBUTES);
        manager.createNotificationChannel(bell);

        NotificationChannel silent = new NotificationChannel(
                CHANNEL_SILENT, "Sesiones Pomodoro (sin sonido)", NotificationManager.IMPORTANCE_LOW);
        silent.setDescription("Notificaciones al terminar sesiones, sin sonido");
        silent.setSound(null, null);
        silent.enableVibration(false);
        manager.createNotificationChannel(silent);
    }

    public static void notifySessionFinished(Context context, String title, String message,
                                             boolean sound, boolean vibrate) {
        boolean canNotify = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU
                || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED;

        if (canNotify) {
            postNotification(context, title, message, sound);
        } else if (sound) {
            // Sin permiso de notificaciones igualmente suena el timbre
            playBell(context);
        }

        if (vibrate) vibrate(context);
    }

    private static void postNotification(Context context, String title, String message, boolean sound) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context, 0, intent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(
                context, sound ? CHANNEL_BELL : CHANNEL_SILENT)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(sound ? NotificationCompat.PRIORITY_HIGH : NotificationCompat.PRIORITY_LOW)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent);

        // Android 7 (API 24-25) no usa canales: el sonido se pide por notificación
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            if (sound) builder.setSound(bellUri(context));
            else builder.setSilent(true);
        }

        try {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, builder.build());
        } catch (SecurityException ignored) { }
    }

    private static void playBell(Context context) {
        try {
            MediaPlayer player = MediaPlayer.create(
                    context, R.raw.timbre_1, BELL_ATTRIBUTES, AudioManager.AUDIO_SESSION_ID_GENERATE);
            if (player == null) return;
            player.setOnCompletionListener(MediaPlayer::release);
            player.start();
        } catch (Exception ignored) { }
    }

    @SuppressWarnings("deprecation")
    private static void vibrate(Context context) {
        Vibrator vibrator;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            VibratorManager vm = (VibratorManager) context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
            vibrator = vm.getDefaultVibrator();
        } else {
            vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        }
        if (vibrator == null || !vibrator.hasVibrator()) return;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));
        } else {
            vibrator.vibrate(500);
        }
    }
}
