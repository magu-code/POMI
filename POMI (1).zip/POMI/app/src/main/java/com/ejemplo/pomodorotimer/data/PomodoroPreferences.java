package com.ejemplo.pomodorotimer.data;

import android.content.Context;
import android.content.SharedPreferences;

public class PomodoroPreferences {

    private static final String FILE = "pomodoro_prefs";
    private static final String WORK_MIN = "work_min";
    private static final String SHORT_BREAK_MIN = "short_break_min";
    private static final String LONG_BREAK_MIN = "long_break_min";
    private static final String COMPLETED_TODAY = "completed_today";
    private static final String LAST_DATE = "last_date";
    private static final String SOUND_ENABLED = "sound_enabled";
    private static final String VIBRATION_ENABLED = "vibration_enabled";

    private final SharedPreferences prefs;

    public PomodoroPreferences(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public int getWorkMinutes() { return prefs.getInt(WORK_MIN, 25); }
    public int getShortBreakMinutes() { return prefs.getInt(SHORT_BREAK_MIN, 5); }
    public int getLongBreakMinutes() { return prefs.getInt(LONG_BREAK_MIN, 15); }
    public int getCompletedToday() { return prefs.getInt(COMPLETED_TODAY, 0); }
    public String getLastDate() { return prefs.getString(LAST_DATE, ""); }
    public boolean isSoundEnabled() { return prefs.getBoolean(SOUND_ENABLED, true); }
    public boolean isVibrationEnabled() { return prefs.getBoolean(VIBRATION_ENABLED, true); }

    public void setWorkMinutes(int v) { prefs.edit().putInt(WORK_MIN, v).apply(); }
    public void setShortBreakMinutes(int v) { prefs.edit().putInt(SHORT_BREAK_MIN, v).apply(); }
    public void setLongBreakMinutes(int v) { prefs.edit().putInt(LONG_BREAK_MIN, v).apply(); }
    public void setCompletedToday(int v) { prefs.edit().putInt(COMPLETED_TODAY, v).apply(); }
    public void setLastDate(String v) { prefs.edit().putString(LAST_DATE, v).apply(); }
    public void setSoundEnabled(boolean v) { prefs.edit().putBoolean(SOUND_ENABLED, v).apply(); }
    public void setVibrationEnabled(boolean v) { prefs.edit().putBoolean(VIBRATION_ENABLED, v).apply(); }
}
