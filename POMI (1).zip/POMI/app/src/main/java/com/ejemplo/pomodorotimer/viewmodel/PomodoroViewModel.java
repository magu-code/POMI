package com.ejemplo.pomodorotimer.viewmodel;

import android.app.Application;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.ejemplo.pomodorotimer.data.PomodoroDatabaseHelper;
import com.ejemplo.pomodorotimer.data.PomodoroPreferences;
import com.ejemplo.pomodorotimer.model.PomodoroState;
import com.ejemplo.pomodorotimer.model.SessionType;
import com.ejemplo.pomodorotimer.notifications.PomodoroNotifier;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class PomodoroViewModel extends AndroidViewModel {

    private static final long TICK_MS = 200L;

    private final PomodoroPreferences prefs;
    private final MutableLiveData<PomodoroState> state = new MutableLiveData<>();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private int workSeconds;
    private int shortBreakSeconds;
    private int longBreakSeconds;

    private long endTimeMillis = 0L;

    /** Día (yyyy-MM-dd) al que corresponde el contador de pomodoros completados */
    private String currentDay;

    /**
     * Bucle del temporizador. Se calcula el tiempo restante contra la hora de fin (no se va
     * restando 1 por tick), así no se desfasa aunque el tick llegue tarde.
     */
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            PomodoroState s = current();
            if (!s.isRunning) return;

            // Redondeo hacia arriba: al iniciar se ve 25:00 y no 24:59
            int remaining = (int) ((endTimeMillis - System.currentTimeMillis() + 999L) / 1000L);
            if (remaining <= 0) {
                state.setValue(s.withSecondsRemaining(0).withRunning(false));
                onSessionFinished();
                return;
            }
            if (remaining != s.secondsRemaining) {
                state.setValue(s.withSecondsRemaining(remaining));
            }
            handler.postDelayed(this, TICK_MS);
        }
    };

    public PomodoroViewModel(@NonNull Application app) {
        super(app);
        prefs = new PomodoroPreferences(app);

        workSeconds = prefs.getWorkMinutes() * 60;
        shortBreakSeconds = prefs.getShortBreakMinutes() * 60;
        longBreakSeconds = prefs.getLongBreakMinutes() * 60;

        String today = todayKey();
        int completed = today.equals(prefs.getLastDate()) ? prefs.getCompletedToday() : 0;
        currentDay = today;
        prefs.setLastDate(today);
        prefs.setCompletedToday(completed);

        state.setValue(new PomodoroState(
                SessionType.WORK, workSeconds, workSeconds, false, completed));
    }

    public LiveData<PomodoroState> getState() {
        return state;
    }

    private PomodoroState current() {
        return state.getValue();
    }

    private String todayKey() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
    }

    public void toggleTimer() {
        if (current().isRunning) pauseTimer();
        else startTimer();
    }

    private void startTimer() {
        if (current().secondsRemaining <= 0) resetTimer();

        endTimeMillis = System.currentTimeMillis() + current().secondsRemaining * 1000L;
        state.setValue(current().withRunning(true));

        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    private void pauseTimer() {
        handler.removeCallbacks(tick);
        state.setValue(current().withRunning(false));
    }

    public void resetTimer() {
        handler.removeCallbacks(tick);
        PomodoroState s = current();
        state.setValue(s.withTotal(durationFor(s.sessionType)).withRunning(false));
    }

    /** Saltar la sesión actual: no cuenta como pomodoro completado ni da descanso largo */
    public void skipSession() {
        handler.removeCallbacks(tick);
        moveToNextSession(false);
    }

    public void selectSession(SessionType type) {
        handler.removeCallbacks(tick);
        state.setValue(current().withSession(type, durationFor(type)));
    }

    private int durationFor(SessionType type) {
        switch (type) {
            case SHORT_BREAK:
                return shortBreakSeconds;
            case LONG_BREAK:
                return longBreakSeconds;
            case WORK:
            default:
                return workSeconds;
        }
    }

    private void onSessionFinished() {
        SessionType finishedType = current().sessionType;

        String title;
        String message;
        switch (finishedType) {
            case SHORT_BREAK:
                title = "Descanso terminado ☕";
                message = "Volvamos al trabajo";
                break;
            case LONG_BREAK:
                title = "Descanso largo terminado 🌿";
                message = "Empecemos de nuevo";
                break;
            case WORK:
            default:
                title = "¡Trabajo terminado! 🍅";
                message = "Es hora de un descanso";
                break;
        }
        PomodoroNotifier.notifySessionFinished(
                getApplication(), title, message,
                prefs.isSoundEnabled(), prefs.isVibrationEnabled());

        if (finishedType == SessionType.WORK) {
            // Si pasó la medianoche con la app abierta, el contador diario arranca de cero
            String today = todayKey();
            int base = today.equals(currentDay) ? current().completedPomodoros : 0;
            currentDay = today;
            int newCount = base + 1;
            state.setValue(current().withCompletedPomodoros(newCount));
            prefs.setCompletedToday(newCount);
            prefs.setLastDate(today);

            try {
                PomodoroDatabaseHelper dbHelper = new PomodoroDatabaseHelper(getApplication());
                int workMinutes = workSeconds / 60;
                dbHelper.addRecord(today, workMinutes, "pomodoro");
                if (newCount > 0 && newCount % 4 == 0) {
                    dbHelper.addRecord(today, workMinutes * 4, "meta");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        moveToNextSession(finishedType == SessionType.WORK);
    }

    private void moveToNextSession(boolean workCompleted) {
        PomodoroState s = current();
        SessionType next;
        if (s.sessionType == SessionType.WORK) {
            // Descanso largo cada 4 pomodoros completados (nunca por saltar una sesión)
            boolean isLong = workCompleted
                    && s.completedPomodoros > 0
                    && s.completedPomodoros % 4 == 0;
            next = isLong ? SessionType.LONG_BREAK : SessionType.SHORT_BREAK;
        } else {
            next = SessionType.WORK;
        }
        state.setValue(s.withSession(next, durationFor(next)));
    }

    public void updateDurations(int workMin, int shortMin, int longMin) {
        // Se aplican de inmediato en memoria y luego se persisten
        workSeconds = workMin * 60;
        shortBreakSeconds = shortMin * 60;
        longBreakSeconds = longMin * 60;
        PomodoroState s = current();
        if (!s.isRunning) {
            state.setValue(s.withTotal(durationFor(s.sessionType)));
        }
        prefs.setWorkMinutes(workMin);
        prefs.setShortBreakMinutes(shortMin);
        prefs.setLongBreakMinutes(longMin);
    }

    @Override
    protected void onCleared() {
        handler.removeCallbacks(tick);
        super.onCleared();
    }
}
