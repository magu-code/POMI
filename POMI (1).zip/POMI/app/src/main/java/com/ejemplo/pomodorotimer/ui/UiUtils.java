package com.ejemplo.pomodorotimer.ui;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.View;

import androidx.core.graphics.ColorUtils;

import java.util.Locale;

public final class UiUtils {

    private UiUtils() { }

    public static int dp(Context context, float value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    public static GradientDrawable roundRect(int color, float radiusPx) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.RECTANGLE);
        d.setColor(color);
        d.setCornerRadius(radiusPx);
        return d;
    }

    public static GradientDrawable roundRectStroke(int fill, float radiusPx, int strokeColor, int strokePx) {
        GradientDrawable d = roundRect(fill, radiusPx);
        d.setStroke(strokePx, strokeColor);
        return d;
    }

    /** Píldora: esquinas completamente redondeadas */
    public static GradientDrawable pill(int color) {
        return roundRect(color, 1000f);
    }

    public static GradientDrawable oval(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        return d;
    }

    public static int withAlpha(int color, float alpha) {
        return ColorUtils.setAlphaComponent(color, Math.round(alpha * 255));
    }

    /** Fondo con forma + recorte, para que el ripple no se salga de las esquinas redondeadas */
    public static void setShapedBackground(View view, Drawable background) {
        view.setBackground(background);
        view.setClipToOutline(true);
    }

    /** Ripple estándar para usar como foreground de vistas clicables */
    public static Drawable selectableForeground(Context context) {
        TypedValue out = new TypedValue();
        context.getTheme().resolveAttribute(android.R.attr.selectableItemBackground, out, true);
        return context.getDrawable(out.resourceId);
    }

    public static String formatDuration(long ms) {
        long totalSec = ms / 1000;
        return String.format(Locale.getDefault(), "%d:%02d", totalSec / 60, totalSec % 60);
    }
}
