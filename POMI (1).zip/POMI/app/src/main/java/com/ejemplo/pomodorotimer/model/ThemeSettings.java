package com.ejemplo.pomodorotimer.model;

import java.util.Objects;

public final class ThemeSettings {

    public final String paletteId;
    public final ThemeMode mode;

    public ThemeSettings() {
        this("tomate", ThemeMode.SYSTEM);
    }

    public ThemeSettings(String paletteId, ThemeMode mode) {
        this.paletteId = paletteId;
        this.mode = mode;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ThemeSettings)) return false;
        ThemeSettings that = (ThemeSettings) o;
        return paletteId.equals(that.paletteId) && mode == that.mode;
    }

    @Override
    public int hashCode() {
        return Objects.hash(paletteId, mode);
    }
}
