package com.ejemplo.pomodorotimer.ui;

import android.content.res.ColorStateList;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ejemplo.pomodorotimer.databinding.ItemGoalBinding;
import com.ejemplo.pomodorotimer.model.Goal;
import com.ejemplo.pomodorotimer.ui.theme.AppTheme;

import java.util.ArrayList;
import java.util.List;

public class GoalAdapter extends RecyclerView.Adapter<GoalAdapter.ViewHolder> {

    public interface Listener {
        void onGoalCheck(Goal goal, boolean checked);
        void onDeleteGoal(Goal goal);
    }

    private final List<Goal> items = new ArrayList<>();
    private final Listener listener;
    private AppTheme theme;
    private int accent;

    public GoalAdapter(Listener listener) {
        this.listener = listener;
    }

    public void setTheme(AppTheme theme, int accent) {
        this.theme = theme;
        this.accent = accent;
        notifyDataSetChanged();
    }

    public void submit(List<Goal> newItems) {
        items.clear();
        items.addAll(newItems);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemGoalBinding binding = ItemGoalBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Goal goal = items.get(position);
        holder.bind(goal, listener, theme, accent);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        private final ItemGoalBinding b;

        ViewHolder(ItemGoalBinding binding) {
            super(binding.getRoot());
            b = binding;
        }

        void bind(Goal goal, Listener listener, AppTheme theme, int accent) {
            b.tvGoalName.setText(goal.name);
            b.tvGoalDuration.setText(goal.durationMinutes + " min");
            b.checkboxGoal.setOnCheckedChangeListener(null);
            b.checkboxGoal.setChecked(goal.isCompleted);

            if (theme != null) {
                b.tvGoalName.setTextColor(goal.isCompleted ? theme.onSurfaceVariant : theme.onSurface);
                b.tvGoalDuration.setTextColor(theme.onSurfaceVariant);
                b.checkboxGoal.setButtonTintList(ColorStateList.valueOf(accent != 0 ? accent : theme.primary));
            }

            if (goal.isCompleted) {
                b.tvGoalName.setPaintFlags(b.tvGoalName.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            } else {
                b.tvGoalName.setPaintFlags(b.tvGoalName.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
            }

            b.checkboxGoal.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (listener != null) listener.onGoalCheck(goal, isChecked);
            });

            b.btnDelete.setOnClickListener(v -> {
                if (listener != null) listener.onDeleteGoal(goal);
            });
        }
    }
}
