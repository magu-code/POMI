package com.ejemplo.pomodorotimer.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

/** RecyclerView que crece con su contenido hasta 420dp y desde ahí hace scroll */
public class MaxHeightRecyclerView extends RecyclerView {

    private final int maxHeightPx;

    public MaxHeightRecyclerView(Context context) {
        this(context, null);
    }

    public MaxHeightRecyclerView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        maxHeightPx = UiUtils.dp(context, 420);
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int mode = View.MeasureSpec.getMode(heightSpec);
        int size = View.MeasureSpec.getSize(heightSpec);
        int limit = mode == View.MeasureSpec.UNSPECIFIED ? maxHeightPx : Math.min(size, maxHeightPx);
        super.onMeasure(widthSpec, View.MeasureSpec.makeMeasureSpec(limit, View.MeasureSpec.AT_MOST));
    }
}
