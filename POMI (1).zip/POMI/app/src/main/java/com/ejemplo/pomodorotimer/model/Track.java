package com.ejemplo.pomodorotimer.model;

import android.net.Uri;

import androidx.annotation.Nullable;

public final class Track {

    public final String id;
    public final String title;
    public final String artist;
    public final String album;
    public final long durationMs;
    @Nullable
    public final String artworkUri;
    public final Uri uri;
    public final boolean isDefault;

    public Track(String id, String title, String artist, String album, long durationMs,
                 @Nullable String artworkUri, Uri uri, boolean isDefault) {
        this.id = id;
        this.title = title;
        this.artist = artist;
        this.album = album;
        this.durationMs = durationMs;
        this.artworkUri = artworkUri;
        this.uri = uri;
        this.isDefault = isDefault;
    }
}
