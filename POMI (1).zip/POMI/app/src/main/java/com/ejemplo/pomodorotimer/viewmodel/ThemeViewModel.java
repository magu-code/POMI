package com.ejemplo.pomodorotimer.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.ejemplo.pomodorotimer.data.ThemePreferences;
import com.ejemplo.pomodorotimer.model.ThemeMode;
import com.ejemplo.pomodorotimer.model.ThemeSettings;
import com.ejemplo.pomodorotimer.ui.theme.AppTheme;

public class ThemeViewModel extends AndroidViewModel {

    private final ThemePreferences prefs;
    private final MutableLiveData<ThemeSettings> settings = new MutableLiveData<>();

    public ThemeViewModel(@NonNull Application app) {
        super(app);
        prefs = new ThemePreferences(app);
        settings.setValue(prefs.getSettings());
    }

    public LiveData<ThemeSettings> getSettings() {
        return settings;
    }

    public void setPalette(String id) {
        prefs.setPalette(id);
        settings.setValue(prefs.getSettings());
    }

    public void setMode(ThemeMode mode) {
        prefs.setMode(mode);
        settings.setValue(prefs.getSettings());
        // Si el modo cambia, AppCompat recrea la Activity con la configuración nueva
        AppCompatDelegate.setDefaultNightMode(AppTheme.nightModeFor(mode));
    }
}
