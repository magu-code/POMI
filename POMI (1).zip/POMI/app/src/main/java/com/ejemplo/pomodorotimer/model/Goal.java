package com.ejemplo.pomodorotimer.model;

public class Goal {
    public final String id;
    public final String name;
    public final int durationMinutes;
    public final boolean isCompleted;

    public Goal(String id, String name, int durationMinutes, boolean isCompleted) {
        this.id = id;
        this.name = name;
        this.durationMinutes = durationMinutes;
        this.isCompleted = isCompleted;
    }
}
