package com.ejemplo.pomodorotimer.ui;

import android.app.Dialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.media3.common.Player;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ejemplo.pomodorotimer.databinding.SheetPlaylistBinding;
import com.ejemplo.pomodorotimer.model.MusicState;
import com.ejemplo.pomodorotimer.model.Track;
import com.ejemplo.pomodorotimer.ui.theme.AppTheme;
import com.ejemplo.pomodorotimer.ui.theme.ThemeApplier;
import com.ejemplo.pomodorotimer.viewmodel.MusicViewModel;
import com.ejemplo.pomodorotimer.viewmodel.ThemeViewModel;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import androidx.lifecycle.ViewModelProvider;

import java.util.List;

/** Lista de reproducción (antes ModalBottomSheet + PlaylistContent) */
public class PlaylistBottomSheet extends BottomSheetDialogFragment {

    private static final String ARG_ACCENT = "accent";
    private int accent;

    public static PlaylistBottomSheet newInstance(int accent) {
        PlaylistBottomSheet sheet = new PlaylistBottomSheet();
        Bundle args = new Bundle();
        args.putInt(ARG_ACCENT, accent);
        sheet.setArguments(args);
        return sheet;
    }

    private SheetPlaylistBinding b;
    private MusicViewModel musicViewModel;
    private TrackAdapter adapter;
    private AppTheme theme;

    /** Selector de archivos del sistema (SAF): no hacen falta permisos de almacenamiento */
    private final ActivityResultLauncher<String[]> pickAudio = registerForActivityResult(
            new ActivityResultContracts.OpenMultipleDocuments(), uris -> {
                if (uris == null || uris.isEmpty()) return;
                for (Uri uri : uris) {
                    try {
                        requireContext().getContentResolver().takePersistableUriPermission(
                                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (SecurityException ignored) { }
                }
                musicViewModel.addUserTracks(uris);
            });

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        b = SheetPlaylistBinding.inflate(inflater, container, false);
        return b.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ViewModelProvider provider = new ViewModelProvider(requireActivity());
        musicViewModel = provider.get(MusicViewModel.class);
        ThemeViewModel themeViewModel = provider.get(ThemeViewModel.class);

        accent = requireArguments().getInt(ARG_ACCENT);
        theme = AppTheme.from(requireContext(), themeViewModel.getSettings().getValue());

        adapter = new TrackAdapter(new TrackAdapter.Listener() {
            @Override
            public void onTrackClick(Track track) {
                musicViewModel.playTrack(track);
                dismiss();
            }

            @Override
            public void onRemoveTrack(Track track) {
                musicViewModel.removeTrack(track);
            }
        });
        adapter.setTheme(theme, accent);
        b.trackList.setLayoutManager(new LinearLayoutManager(requireContext()));
        b.trackList.setAdapter(adapter);

        // Colores del encabezado
        ThemeApplier.apply(b.getRoot(), theme);
        b.btnAdd.setBackgroundTintList(ColorStateList.valueOf(theme.surfaceVariant));
        b.btnAdd.setTextColor(theme.onSurface);
        b.btnAdd.setIconTint(ColorStateList.valueOf(theme.onSurface));
        b.btnAdd.setOnClickListener(v -> pickAudio.launch(new String[]{"audio/*"}));

        b.btnShuffle.setOnClickListener(v -> musicViewModel.toggleShuffle());
        b.btnRepeat.setOnClickListener(v -> musicViewModel.cycleRepeatMode());

        musicViewModel.getState().observe(getViewLifecycleOwner(), this::render);
    }

    private void render(MusicState state) {
        List<Track> tracks = state.playlist;
        String currentId = state.currentTrack != null ? state.currentTrack.id : null;
        adapter.submit(tracks, currentId);

        int activeTint = accent != 0 ? accent : theme.primary;
        int inactiveTint = theme.onSurfaceVariant;

        b.btnShuffle.setImageTintList(ColorStateList.valueOf(state.shuffleEnabled ? activeTint : inactiveTint));
        b.btnRepeat.setImageTintList(ColorStateList.valueOf(state.repeatMode != Player.REPEAT_MODE_OFF ? activeTint : inactiveTint));
        b.btnRepeat.setAlpha(state.repeatMode != Player.REPEAT_MODE_OFF ? 1.0f : 0.6f);
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog instanceof BottomSheetDialog && theme != null) {
            BottomSheetDialog sheetDialog = (BottomSheetDialog) dialog;
            FrameLayout sheet = sheetDialog.findViewById(com.google.android.material.R.id.design_bottom_sheet);
            if (sheet != null) {
                sheet.setBackgroundTintList(ColorStateList.valueOf(theme.surface));
            }
            BottomSheetBehavior<FrameLayout> behavior = sheetDialog.getBehavior();
            behavior.setSkipCollapsed(true);
            behavior.setState(BottomSheetBehavior.STATE_EXPANDED);
        }
    }

    @Override
    public void onDestroyView() {
        b = null;
        super.onDestroyView();
    }
}
