package com.ejemplo.pomodorotimer.ui.theme;

import com.ejemplo.pomodorotimer.model.SessionType;

/** Colores de sesión de una paleta (trabajo / descanso corto / descanso largo) */
public final class SessionColors {

    public final int work;
    public final int shortBreak;
    public final int longBreak;

    public SessionColors(int work, int shortBreak, int longBreak) {
        this.work = work;
        this.shortBreak = shortBreak;
        this.longBreak = longBreak;
    }

    public int forSession(SessionType type) {
        switch (type) {
            case SHORT_BREAK:
                return shortBreak;
            case LONG_BREAK:
                return longBreak;
            case WORK:
            default:
                return work;
        }
    }
}
