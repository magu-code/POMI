package com.ejemplo.pomodorotimer.ui.theme;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Para agregar un tema de color, sumá una entrada a ALL. */
public final class AppPalettes {

    private AppPalettes() { }

    public static final List<AppPalette> ALL = Collections.unmodifiableList(Arrays.asList(
            new AppPalette("tomate", "Tomate",
                    new SessionColors(0xFFE53935, 0xFF43A047, 0xFF1E88E5)),
            new AppPalette("oceano", "Océano",
                    new SessionColors(0xFF0288D1, 0xFF00897B, 0xFF5C6BC0)),
            new AppPalette("bosque", "Bosque",
                    new SessionColors(0xFF2E7D32, 0xFF9E9D24, 0xFF00796B)),
            new AppPalette("lavanda", "Lavanda",
                    new SessionColors(0xFF7E57C2, 0xFF00ACC1, 0xFFD81B60)),
            new AppPalette("atardecer", "Atardecer",
                    new SessionColors(0xFFF4511E, 0xFFF9A825, 0xFF8E24AA)),
            new AppPalette("grafito", "Grafito",
                    new SessionColors(0xFF607D8B, 0xFF78909C, 0xFF455A64))
    ));

    public static final AppPalette DEFAULT = ALL.get(0);

    public static AppPalette byId(String id) {
        for (AppPalette p : ALL) {
            if (p.id.equals(id)) return p;
        }
        return DEFAULT;
    }
}
