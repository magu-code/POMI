package com.ejemplo.pomodorotimer;

import android.app.AlertDialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.Window;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.lifecycle.ViewModelProvider;

import com.ejemplo.pomodorotimer.data.PomodoroDatabaseHelper;
import com.ejemplo.pomodorotimer.databinding.ActivityStatsBinding;
import com.ejemplo.pomodorotimer.ui.theme.AppTheme;
import com.ejemplo.pomodorotimer.ui.theme.ThemeApplier;
import com.ejemplo.pomodorotimer.viewmodel.ThemeViewModel;

public class StatsActivity extends AppCompatActivity {

    private ActivityStatsBinding b;
    private PomodoroDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        b = ActivityStatsBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());

        dbHelper = new PomodoroDatabaseHelper(this);

        setupInsets();
        setupTheme();

        b.btnBack.setOnClickListener(v -> finish());
        b.btnClearStats.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Reiniciar estadísticas")
                .setMessage("¿Estás seguro de que deseas borrar todos los registros de pomodoros y metas?")
                .setPositiveButton("Borrar", (dialog, which) -> {
                    try (SQLiteDatabase db = dbHelper.getWritableDatabase()) {
                        db.delete(PomodoroDatabaseHelper.TABLE_STATS, null, null);
                        loadStats();
                    } catch (Exception ignored) { }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show());

        loadStats();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadStats();
    }

    private void setupInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(b.getRoot(), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            v.setPadding(bars.left, 0, bars.right, 0);
            b.appBar.setPadding(0, bars.top, 0, 0);
            b.scroll.setPadding(0, 0, 0, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
        ViewCompat.requestApplyInsets(b.getRoot());
    }

    private void setupTheme() {
        ThemeViewModel themeVm = new ViewModelProvider(this).get(ThemeViewModel.class);
        themeVm.getSettings().observe(this, settings -> {
            if (b == null) return;
            AppTheme theme = AppTheme.from(this, settings);
            Window window = getWindow();
            View decor = window.getDecorView();
            decor.setBackgroundColor(theme.background);

            WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(window, decor);
            controller.setAppearanceLightStatusBars(!theme.dark);
            controller.setAppearanceLightNavigationBars(!theme.dark);

            ThemeApplier.apply(b.getRoot(), theme);

            b.tvTotalPomodoros.setTextColor(theme.sessionColors.work);
            b.tvTotalMetas.setTextColor(theme.sessionColors.longBreak);
        });
    }

    private void loadStats() {
        if (b == null) return;
        try (SQLiteDatabase db = dbHelper.getReadableDatabase()) {
            // Contar pomodoros
            try (Cursor cursorPomodoros = db.rawQuery("SELECT COUNT(*) FROM " + PomodoroDatabaseHelper.TABLE_STATS + 
                    " WHERE " + PomodoroDatabaseHelper.COLUMN_TYPE + " = 'pomodoro'", null)) {
                if (cursorPomodoros.moveToFirst()) {
                    int count = cursorPomodoros.getInt(0);
                    b.tvTotalPomodoros.setText(String.valueOf(count));
                }
            }

            // Contar metas
            try (Cursor cursorMetas = db.rawQuery("SELECT COUNT(*) FROM " + PomodoroDatabaseHelper.TABLE_STATS + 
                    " WHERE " + PomodoroDatabaseHelper.COLUMN_TYPE + " = 'meta'", null)) {
                if (cursorMetas.moveToFirst()) {
                    int count = cursorMetas.getInt(0);
                    b.tvTotalMetas.setText(String.valueOf(count));
                }
            }
        } catch (Exception ignored) { }
    }

    @Override
    protected void onDestroy() {
        b = null;
        super.onDestroy();
    }
}
