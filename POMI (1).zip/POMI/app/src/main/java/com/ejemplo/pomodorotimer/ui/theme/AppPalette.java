package com.ejemplo.pomodorotimer.ui.theme;

public final class AppPalette {

    public final String id;
    public final String label;
    public final SessionColors colors;

    public AppPalette(String id, String label, SessionColors colors) {
        this.id = id;
        this.label = label;
        this.colors = colors;
    }
}
