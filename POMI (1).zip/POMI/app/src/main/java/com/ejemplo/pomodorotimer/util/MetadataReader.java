package com.ejemplo.pomodorotimer.util;

import android.content.Context;
import android.media.MediaMetadataRetriever;
import android.net.Uri;

import androidx.annotation.Nullable;

import com.ejemplo.pomodorotimer.model.Track;

import java.io.File;
import java.io.FileOutputStream;

public final class MetadataReader {

    private MetadataReader() { }

    public static Track read(Context context, Uri uri) {
        return read(context, uri, null, null, uri.toString(), false);
    }

    public static Track read(Context context, Uri uri,
                             @Nullable String fallbackTitle,
                             @Nullable String fallbackArtist,
                             String id,
                             boolean isDefault) {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(context, uri);

            String title = firstNonNull(
                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE),
                    fallbackTitle,
                    titleFromUri(uri),
                    "Pista desconocida");

            String artist = firstNonNull(
                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST),
                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST),
                    fallbackArtist,
                    "Artista desconocido");

            String album = firstNonNull(
                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM), "");

            long duration = 0L;
            String durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            if (durationStr != null) {
                try {
                    duration = Long.parseLong(durationStr);
                } catch (NumberFormatException ignored) { }
            }

            String artworkUri = extractArtwork(context, retriever, uri);

            return new Track(id, title, artist, album, duration, artworkUri, uri, isDefault);
        } catch (Exception e) {
            return new Track(
                    id,
                    firstNonNull(fallbackTitle, uri.getLastPathSegment(), "Pista"),
                    firstNonNull(fallbackArtist, "Desconocido"),
                    "", 0L, null, uri, isDefault);
        } finally {
            try {
                retriever.release();
            } catch (Exception ignored) { }
        }
    }

    @Nullable
    private static String titleFromUri(Uri uri) {
        String segment = uri.getLastPathSegment();
        if (segment == null) return null;
        int slash = segment.lastIndexOf('/');
        String name = slash >= 0 ? segment.substring(slash + 1) : segment;
        int dot = name.lastIndexOf('.');
        return dot >= 0 ? name.substring(0, dot) : name;
    }

    private static String firstNonNull(String... values) {
        for (String v : values) {
            if (v != null) return v;
        }
        return "";
    }

    @Nullable
    private static String extractArtwork(Context context, MediaMetadataRetriever retriever, Uri sourceUri) {
        try {
            byte[] picture = retriever.getEmbeddedPicture();
            if (picture == null) return null;

            File dir = new File(context.getCacheDir(), "artwork");
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
            File file = new File(dir, sourceUri.toString().hashCode() + ".img");
            if (!file.exists()) {
                try (FileOutputStream out = new FileOutputStream(file)) {
                    out.write(picture);
                }
            }
            return Uri.fromFile(file).toString();
        } catch (Exception e) {
            return null;
        }
    }
}
