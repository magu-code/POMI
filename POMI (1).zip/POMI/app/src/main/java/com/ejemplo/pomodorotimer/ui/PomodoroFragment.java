package com.ejemplo.pomodorotimer.ui;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.widget.ImageViewCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.bumptech.glide.Glide;
import com.ejemplo.pomodorotimer.R;
import com.ejemplo.pomodorotimer.StatsActivity;
import com.ejemplo.pomodorotimer.databinding.FragmentPomodoroBinding;
import com.ejemplo.pomodorotimer.model.MusicState;
import com.ejemplo.pomodorotimer.model.PomodoroState;
import com.ejemplo.pomodorotimer.model.SessionType;
import com.ejemplo.pomodorotimer.model.Track;
import com.ejemplo.pomodorotimer.ui.theme.AppTheme;
import com.ejemplo.pomodorotimer.ui.theme.ThemeApplier;
import com.ejemplo.pomodorotimer.viewmodel.MusicViewModel;
import com.ejemplo.pomodorotimer.viewmodel.PomodoroViewModel;
import com.ejemplo.pomodorotimer.viewmodel.ThemeViewModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class PomodoroFragment extends Fragment {

    private static final String KEY_LAST_TYPE = "last_type";
    private static final String KEY_LAST_RUNNING = "last_running";
    private static final String TAG_PLAYLIST = "playlist";

    private FragmentPomodoroBinding b;
    private PomodoroViewModel viewModel;
    private MusicViewModel musicViewModel;

    private AppTheme theme;
    private PomodoroState lastState;
    private MusicState lastMusic;

    /** Color de acento actual (se anima al cambiar de sesión) */
    private int accent;
    private int accentTarget;
    private boolean accentInitialized = false;
    private ValueAnimator accentAnimator;

    private final List<TextView> selectorViews = new ArrayList<>();

    // Integración música <-> Pomodoro. Sobreviven a rotaciones (se guardan en el estado de la
    // instancia) para no re-disparar la pausa al recrear la pantalla.
    @Nullable
    private SessionType lastType;
    @Nullable
    private Boolean lastRunning;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            String type = savedInstanceState.getString(KEY_LAST_TYPE);
            if (type != null) lastType = SessionType.valueOf(type);
            if (savedInstanceState.containsKey(KEY_LAST_RUNNING)) {
                lastRunning = savedInstanceState.getBoolean(KEY_LAST_RUNNING);
            }
        }
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        if (lastType != null) outState.putString(KEY_LAST_TYPE, lastType.name());
        if (lastRunning != null) outState.putBoolean(KEY_LAST_RUNNING, lastRunning);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        b = FragmentPomodoroBinding.inflate(inflater, container, false);
        return b.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // ViewModels a nivel de Activity: Pomodoro y Ajustes comparten la MISMA instancia
        ViewModelProvider provider = new ViewModelProvider(requireActivity());
        viewModel = provider.get(PomodoroViewModel.class);
        musicViewModel = provider.get(MusicViewModel.class);
        ThemeViewModel themeViewModel = provider.get(ThemeViewModel.class);

        setupInsets();
        buildSessionSelector();

        b.btnGoals.setOnClickListener(v -> showGoals());
        b.btnStats.setOnClickListener(v -> openStats());
        b.btnSettings.setOnClickListener(v -> openSettings());
        b.btnReset.setOnClickListener(v -> viewModel.resetTimer());
        b.btnPlay.setOnClickListener(v -> viewModel.toggleTimer());
        b.btnSkip.setOnClickListener(v -> viewModel.skipSession());

        b.btnPrev.setOnClickListener(v -> musicViewModel.previous());
        b.btnPlayPause.setOnClickListener(v -> musicViewModel.togglePlayPause());
        b.btnNext.setOnClickListener(v -> musicViewModel.next());
        b.btnQueue.setOnClickListener(v -> showPlaylist());
        b.musicTextColumn.setOnClickListener(v -> showPlaylist());

        // El observador del tema va primero: los demás necesitan `theme` ya resuelto
        themeViewModel.getSettings().observe(getViewLifecycleOwner(), settings -> {
            theme = AppTheme.from(requireContext(), settings);
            applyTheme();
        });
        viewModel.getState().observe(getViewLifecycleOwner(), this::onPomodoroState);
        musicViewModel.getState().observe(getViewLifecycleOwner(), state -> {
            lastMusic = state;
            renderMusic();
        });
    }

    @Override
    public void onDestroyView() {
        if (accentAnimator != null) accentAnimator.cancel();
        accentAnimator = null;
        accentInitialized = false;
        selectorViews.clear();
        b = null;
        super.onDestroyView();
    }

    // ---------------------------------------------------------------- navegación

    private void openSettings() {
        getParentFragmentManager().beginTransaction()
                .setReorderingAllowed(true)
                .replace(R.id.fragment_container, new SettingsFragment())
                .addToBackStack(null)
                .commit();
    }

    private void openStats() {
        startActivity(new Intent(requireContext(), StatsActivity.class));
    }

    private void showGoals() {
        if (getParentFragmentManager().findFragmentByTag("goals") != null) return;
        GoalsBottomSheet.newInstance(accent).show(getParentFragmentManager(), "goals");
    }

    private void showPlaylist() {
        if (getParentFragmentManager().findFragmentByTag(TAG_PLAYLIST) != null) return;
        PlaylistBottomSheet.newInstance(accent).show(getParentFragmentManager(), TAG_PLAYLIST);
    }

    // ---------------------------------------------------------------- edge-to-edge

    private void setupInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(b.getRoot(), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            v.setPadding(bars.left, 0, bars.right, 0);
            b.appBar.setPadding(0, bars.top, 0, 0);
            b.musicBar.setPadding(0, 0, 0, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
        ViewCompat.requestApplyInsets(b.getRoot());
    }

    // ---------------------------------------------------------------- selector de sesión

    private void buildSessionSelector() {
        b.sessionSelector.removeAllViews();
        selectorViews.clear();

        SessionType[] types = SessionType.values();
        for (int i = 0; i < types.length; i++) {
            SessionType type = types[i];

            TextView tv = new TextView(requireContext());
            tv.setText(type.getLabel());
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            tv.setGravity(Gravity.CENTER);
            tv.setMaxLines(1);
            tv.setPadding(0, UiUtils.dp(requireContext(), 10), 0, UiUtils.dp(requireContext(), 10));
            tv.setClickable(true);
            tv.setFocusable(true);
            tv.setForeground(UiUtils.selectableForeground(requireContext()));
            tv.setOnClickListener(v -> viewModel.selectSession(type));

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i > 0) lp.setMarginStart(UiUtils.dp(requireContext(), 8));
            b.sessionSelector.addView(tv, lp);
            selectorViews.add(tv);
        }
    }

    private void updateSelector() {
        if (theme == null) return;
        SessionType selected = lastState != null ? lastState.sessionType : SessionType.WORK;
        SessionType[] types = SessionType.values();

        for (int i = 0; i < selectorViews.size(); i++) {
            TextView tv = selectorViews.get(i);
            boolean isSelected = types[i] == selected;
            UiUtils.setShapedBackground(tv,
                    UiUtils.pill(isSelected ? accent : theme.surfaceVariant));
            tv.setTextColor(isSelected ? Color.WHITE : theme.onSurfaceVariant);
            tv.setTypeface(null, isSelected ? Typeface.BOLD : Typeface.NORMAL);
        }
    }

    // ---------------------------------------------------------------- tema

    private void applyTheme() {
        ThemeApplier.apply(b.getRoot(), theme);

        int variant = theme.surfaceVariant;
        UiUtils.setShapedBackground(b.pill, UiUtils.pill(variant));
        b.progress.setTrackColor(variant);

        b.btnReset.setBackground(UiUtils.oval(variant));
        b.btnSkip.setBackground(UiUtils.oval(variant));
        ImageViewCompat.setImageTintList(b.btnReset, ColorStateList.valueOf(theme.onSurfaceVariant));
        ImageViewCompat.setImageTintList(b.btnSkip, ColorStateList.valueOf(theme.onSurfaceVariant));
        ImageViewCompat.setImageTintList(b.btnPlay, ColorStateList.valueOf(Color.WHITE));

        UiUtils.setShapedBackground(b.artworkBox,
                UiUtils.roundRect(variant, UiUtils.dp(requireContext(), 10)));

        if (lastState != null) renderPomodoro();
        renderMusic();
    }

    // ---------------------------------------------------------------- Pomodoro

    private void onPomodoroState(PomodoroState state) {
        lastState = state;
        syncMusicWithSession(state);
        if (theme != null) renderPomodoro();
    }

    private void renderPomodoro() {
        PomodoroState s = lastState;

        b.timeText.setText(s.timeFormatted());
        b.sessionLabel.setText(s.sessionType.getLabel().toUpperCase(Locale.getDefault()));
        b.completedText.setText(getString(R.string.completed_today, s.completedPomodoros));

        b.btnPlay.setImageResource(s.isRunning ? R.drawable.ic_pause : R.drawable.ic_play_arrow);
        b.btnPlay.setContentDescription(getString(s.isRunning ? R.string.pause : R.string.start));

        // Los cambios pequeños (cada tick) se aplican directo; los grandes (reiniciar, cambiar
        // de sesión) se animan.
        int progress = Math.round(s.progress() * 1000f);
        boolean animate = Math.abs(progress - b.progress.getProgress()) > 20;
        b.progress.setProgressCompat(progress, animate);

        int target = theme.sessionColors.forSession(s.sessionType);
        if (!accentInitialized) {
            accentInitialized = true;
            accent = target;
            accentTarget = target;
            applyAccent();
        } else if (target != accentTarget) {
            animateAccentTo(target);
        } else {
            updateSelector();
        }
    }

    private void animateAccentTo(int target) {
        if (accentAnimator != null) accentAnimator.cancel();
        accentTarget = target;

        ValueAnimator animator = ValueAnimator.ofObject(new ArgbEvaluator(), accent, target);
        animator.setDuration(300);
        animator.addUpdateListener(a -> {
            if (b == null) return;
            accent = (int) a.getAnimatedValue();
            applyAccent();
        });
        accentAnimator = animator;
        animator.start();
    }

    /** Pinta con el color de la sesión actual todo lo que lo usa */
    private void applyAccent() {
        ColorStateList accentList = ColorStateList.valueOf(accent);
        b.progress.setIndicatorColor(accent);
        b.sessionLabel.setTextColor(accent);
        b.btnPlay.setBackground(UiUtils.oval(accent));
        ImageViewCompat.setImageTintList(b.btnPlayPause, accentList);
        ImageViewCompat.setImageTintList(b.musicIcon, accentList);
        updateSelector();
    }

    // ---------------------------------------------------------------- música

    /**
     * Integración música <-> Pomodoro.
     * - Al cambiar a un descanso (termine solo, se salte o se elija) la música se pausa.
     * - Al iniciar el timer en una sesión de trabajo, la música se reanuda.
     */
    private void syncMusicWithSession(PomodoroState s) {
        if (lastType == null) lastType = s.sessionType;
        if (lastRunning == null) lastRunning = s.isRunning;

        if (s.sessionType != lastType) {
            lastType = s.sessionType;
            if (s.sessionType != SessionType.WORK) {
                musicViewModel.onSessionChanged(s.sessionType);
            }
        }
        if (s.isRunning != lastRunning) {
            lastRunning = s.isRunning;
            if (s.isRunning && s.sessionType == SessionType.WORK) {
                musicViewModel.onSessionChanged(SessionType.WORK);
            }
        }
    }

    private void renderMusic() {
        if (theme == null || lastMusic == null) return;

        Track track = lastMusic.currentTrack;
        b.musicTitle.setText(track != null ? track.title : getString(R.string.no_music));
        b.musicArtist.setText(track != null ? track.artist : getString(R.string.pick_track));

        String artwork = track != null ? track.artworkUri : null;
        if (artwork != null) {
            b.artworkImage.setVisibility(View.VISIBLE);
            b.musicIcon.setVisibility(View.GONE);
            Glide.with(b.artworkImage).load(artwork).centerCrop().into(b.artworkImage);
        } else {
            Glide.with(b.artworkImage).clear(b.artworkImage);
            b.artworkImage.setVisibility(View.GONE);
            b.musicIcon.setVisibility(View.VISIBLE);
        }

        b.btnPlayPause.setImageResource(
                lastMusic.isPlaying ? R.drawable.ic_pause : R.drawable.ic_play_arrow);
    }
}
