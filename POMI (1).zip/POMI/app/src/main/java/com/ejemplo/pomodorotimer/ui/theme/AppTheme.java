package com.ejemplo.pomodorotimer.ui.theme;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;

import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.ColorUtils;

import com.ejemplo.pomodorotimer.model.ThemeMode;
import com.ejemplo.pomodorotimer.model.ThemeSettings;

/**
 * Colores resueltos del tema activo (paleta elegida + claro/oscuro).
 * Equivale al ColorScheme de Material 3 que antes armaba Compose: los neutros
 * (fondos y superficies) se tiñen levemente con el color principal de la paleta.
 */
public final class AppTheme {

    private static final int DARK_BG = 0xFF0F0F0F;
    private static final int DARK_SURFACE = 0xFF1A1A1A;
    private static final int DARK_SURFACE_ELEVATED = 0xFF242424;
    private static final int TEXT_PRIMARY = 0xFFEDEDED;
    private static final int TEXT_SECONDARY = 0xFF9E9E9E;

    private static final int LIGHT_BG = 0xFFF7F5F2;
    private static final int LIGHT_SURFACE = 0xFFFFFFFF;
    private static final int LIGHT_SURFACE_ELEVATED = 0xFFEFEDEA;
    private static final int TEXT_PRIMARY_LIGHT = 0xFF1C1B1F;
    private static final int TEXT_SECONDARY_LIGHT = 0xFF5F5F5F;

    public final boolean dark;
    public final SessionColors sessionColors;

    public final int primary;
    public final int onPrimary;
    public final int background;
    public final int onBackground;
    public final int surface;
    public final int onSurface;
    public final int surfaceVariant;
    public final int onSurfaceVariant;

    private AppTheme(boolean dark, AppPalette palette) {
        this.dark = dark;
        this.sessionColors = palette.colors;

        int accent = palette.colors.work;
        primary = accent;
        onPrimary = Color.WHITE;

        if (dark) {
            background = ColorUtils.blendARGB(DARK_BG, accent, 0.05f);
            onBackground = TEXT_PRIMARY;
            surface = ColorUtils.blendARGB(DARK_SURFACE, accent, 0.06f);
            onSurface = TEXT_PRIMARY;
            surfaceVariant = ColorUtils.blendARGB(DARK_SURFACE_ELEVATED, accent, 0.10f);
            onSurfaceVariant = TEXT_SECONDARY;
        } else {
            background = ColorUtils.blendARGB(LIGHT_BG, accent, 0.04f);
            onBackground = TEXT_PRIMARY_LIGHT;
            surface = ColorUtils.blendARGB(LIGHT_SURFACE, accent, 0.02f);
            onSurface = TEXT_PRIMARY_LIGHT;
            surfaceVariant = ColorUtils.blendARGB(LIGHT_SURFACE_ELEVATED, accent, 0.08f);
            onSurfaceVariant = TEXT_SECONDARY_LIGHT;
        }
    }

    /**
     * Usar un Context de Activity: su configuración ya refleja el modo claro/oscuro elegido
     * (AppCompatDelegate.setDefaultNightMode), incluido el caso "Sistema".
     */
    public static AppTheme from(Context activityContext, ThemeSettings settings) {
        int nightFlag = activityContext.getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK;
        boolean dark = nightFlag == Configuration.UI_MODE_NIGHT_YES;
        return new AppTheme(dark, AppPalettes.byId(settings.paletteId));
    }

    public static int nightModeFor(ThemeMode mode) {
        switch (mode) {
            case LIGHT:
                return AppCompatDelegate.MODE_NIGHT_NO;
            case DARK:
                return AppCompatDelegate.MODE_NIGHT_YES;
            case SYSTEM:
            default:
                return AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM;
        }
    }
}
