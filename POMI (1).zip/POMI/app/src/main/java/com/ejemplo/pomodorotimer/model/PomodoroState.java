package com.ejemplo.pomodorotimer.model;

import java.util.Locale;
import java.util.Objects;

/** Estado inmutable del temporizador. Los métodos with... devuelven una copia modificada. */
public final class PomodoroState {

    public final SessionType sessionType;
    public final int secondsRemaining;
    public final int totalSeconds;
    public final boolean isRunning;
    public final int completedPomodoros;

    public PomodoroState() {
        this(SessionType.WORK, 25 * 60, 25 * 60, false, 0);
    }

    public PomodoroState(SessionType sessionType, int secondsRemaining, int totalSeconds,
                         boolean isRunning, int completedPomodoros) {
        this.sessionType = sessionType;
        this.secondsRemaining = secondsRemaining;
        this.totalSeconds = totalSeconds;
        this.isRunning = isRunning;
        this.completedPomodoros = completedPomodoros;
    }

    /** Avance de 0 a 1 */
    public float progress() {
        return totalSeconds == 0 ? 0f : 1f - ((float) secondsRemaining / totalSeconds);
    }

    public String timeFormatted() {
        int min = secondsRemaining / 60;
        int sec = secondsRemaining % 60;
        return String.format(Locale.getDefault(), "%02d:%02d", min, sec);
    }

    public PomodoroState withSecondsRemaining(int seconds) {
        return new PomodoroState(sessionType, seconds, totalSeconds, isRunning, completedPomodoros);
    }

    public PomodoroState withRunning(boolean running) {
        return new PomodoroState(sessionType, secondsRemaining, totalSeconds, running, completedPomodoros);
    }

    public PomodoroState withCompletedPomodoros(int completed) {
        return new PomodoroState(sessionType, secondsRemaining, totalSeconds, isRunning, completed);
    }

    /** Nueva duración total; el tiempo restante vuelve al total */
    public PomodoroState withTotal(int total) {
        return new PomodoroState(sessionType, total, total, isRunning, completedPomodoros);
    }

    /** Cambia de sesión: tiempo restante = total, y el timer queda detenido */
    public PomodoroState withSession(SessionType type, int total) {
        return new PomodoroState(type, total, total, false, completedPomodoros);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PomodoroState)) return false;
        PomodoroState s = (PomodoroState) o;
        return sessionType == s.sessionType
                && secondsRemaining == s.secondsRemaining
                && totalSeconds == s.totalSeconds
                && isRunning == s.isRunning
                && completedPomodoros == s.completedPomodoros;
    }

    @Override
    public int hashCode() {
        return Objects.hash(sessionType, secondsRemaining, totalSeconds, isRunning, completedPomodoros);
    }
}
