package com.ejemplo.pomodorotimer.data;

import android.content.Context;
import android.content.SharedPreferences;

import com.ejemplo.pomodorotimer.model.Goal;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class GoalsPreferences {
    private static final String PREF_NAME = "pomodoro_goals_prefs";
    private static final String KEY_GOALS = "goals_list";

    private final SharedPreferences prefs;

    public GoalsPreferences(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public List<Goal> getGoals() {
        String json = prefs.getString(KEY_GOALS, "[]");
        List<Goal> list = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                list.add(new Goal(
                        obj.optString("id", UUID.randomUUID().toString()),
                        obj.optString("name", ""),
                        obj.optInt("durationMinutes", 25),
                        obj.optBoolean("isCompleted", false)
                ));
            }
        } catch (JSONException ignored) { }
        return list;
    }

    public void saveGoals(List<Goal> goals) {
        JSONArray arr = new JSONArray();
        try {
            for (Goal g : goals) {
                JSONObject obj = new JSONObject();
                obj.put("id", g.id);
                obj.put("name", g.name);
                obj.put("durationMinutes", g.durationMinutes);
                obj.put("isCompleted", g.isCompleted);
                arr.put(obj);
            }
        } catch (JSONException ignored) { }
        prefs.edit().putString(KEY_GOALS, arr.toString()).apply();
    }

    public void addGoal(String name, int durationMinutes) {
        List<Goal> list = getGoals();
        list.add(new Goal(UUID.randomUUID().toString(), name, durationMinutes, false));
        saveGoals(list);
    }

    public void removeGoal(String id) {
        List<Goal> list = getGoals();
        list.removeIf(g -> g.id.equals(id));
        saveGoals(list);
    }

    public void setGoalCompleted(String id, boolean completed) {
        List<Goal> list = getGoals();
        List<Goal> updated = new ArrayList<>();
        for (Goal g : list) {
            if (g.id.equals(id)) {
                updated.add(new Goal(g.id, g.name, g.durationMinutes, completed));
            } else {
                updated.add(g);
            }
        }
        saveGoals(updated);
    }
}
