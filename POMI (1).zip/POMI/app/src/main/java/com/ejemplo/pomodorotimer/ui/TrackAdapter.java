package com.ejemplo.pomodorotimer.ui;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.widget.ImageViewCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.ejemplo.pomodorotimer.R;
import com.ejemplo.pomodorotimer.databinding.ItemTrackBinding;
import com.ejemplo.pomodorotimer.model.Track;
import com.ejemplo.pomodorotimer.ui.theme.AppTheme;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TrackAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public interface Listener {
        void onTrackClick(Track track);
        void onRemoveTrack(Track track);
    }

    private static final int VIEW_TYPE_HEADER = 0;
    private static final int VIEW_TYPE_TRACK = 1;

    public static class AdapterItem {
        public final int type;
        public final String headerTitle;
        public final Track track;

        public AdapterItem(String headerTitle) {
            this.type = VIEW_TYPE_HEADER;
            this.headerTitle = headerTitle;
            this.track = null;
        }

        public AdapterItem(Track track) {
            this.type = VIEW_TYPE_TRACK;
            this.headerTitle = null;
            this.track = track;
        }
    }

    private final Listener listener;
    private final List<AdapterItem> items = new ArrayList<>();
    private String currentId;
    private AppTheme theme;
    private int accent;

    public TrackAdapter(Listener listener) {
        this.listener = listener;
    }

    @SuppressLint("NotifyDataSetChanged")
    public void submit(List<Track> newTracks, String newCurrentId) {
        items.clear();
        currentId = newCurrentId;

        List<Track> defaultTracks = new ArrayList<>();
        List<Track> userTracks = new ArrayList<>();
        for (Track t : newTracks) {
            if (t.isDefault) defaultTracks.add(t);
            else userTracks.add(t);
        }

        if (!defaultTracks.isEmpty()) {
            items.add(new AdapterItem("Pomi Lo-Fi"));
            for (Track t : defaultTracks) items.add(new AdapterItem(t));
        }

        if (!userTracks.isEmpty()) {
            items.add(new AdapterItem("Mis Canciones"));
            for (Track t : userTracks) items.add(new AdapterItem(t));
        }

        notifyDataSetChanged();
    }

    @SuppressLint("NotifyDataSetChanged")
    public void setTheme(AppTheme newTheme, int newAccent) {
        theme = newTheme;
        accent = newAccent;
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        return items.get(position).type;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_HEADER) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_track_header, parent, false);
            return new HeaderHolder(view);
        } else {
            return new TrackHolder(ItemTrackBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (theme == null) return;
        AdapterItem item = items.get(position);

        if (holder instanceof HeaderHolder) {
            HeaderHolder hh = (HeaderHolder) holder;
            hh.titleView.setText(item.headerTitle);
            hh.titleView.setTextColor(theme.primary);
        } else if (holder instanceof TrackHolder) {
            TrackHolder th = (TrackHolder) holder;
            ItemTrackBinding v = th.b;
            Context context = v.getRoot().getContext();
            Track track = item.track;
            boolean isCurrent = track.id.equals(currentId);

            v.row.setBackgroundColor(isCurrent ? UiUtils.withAlpha(accent, 0.12f) : Color.TRANSPARENT);
            v.row.setOnClickListener(view -> listener.onTrackClick(track));
            v.divider.setBackgroundColor(theme.surfaceVariant);

            UiUtils.setShapedBackground(v.artworkBox,
                    UiUtils.roundRect(theme.surfaceVariant, UiUtils.dp(context, 8)));
            if (track.artworkUri != null) {
                v.artworkImage.setVisibility(View.VISIBLE);
                v.trackIcon.setVisibility(View.GONE);
                Glide.with(v.artworkImage).load(track.artworkUri).centerCrop().into(v.artworkImage);
            } else {
                Glide.with(v.artworkImage).clear(v.artworkImage);
                v.artworkImage.setVisibility(View.GONE);
                v.trackIcon.setVisibility(View.VISIBLE);
                v.trackIcon.setImageResource(isCurrent ? R.drawable.ic_equalizer : R.drawable.ic_music_note);
                ImageViewCompat.setImageTintList(v.trackIcon,
                        ColorStateList.valueOf(isCurrent ? accent : theme.onSurfaceVariant));
            }

            v.title.setText(track.title);
            v.title.setTextColor(isCurrent ? accent : theme.onSurface);
            v.title.setTypeface(null, isCurrent ? Typeface.BOLD : Typeface.NORMAL);

            StringBuilder subtitle = new StringBuilder(track.artist);
            if (track.durationMs > 0) {
                subtitle.append(" · ").append(UiUtils.formatDuration(track.durationMs));
            }
            v.subtitle.setText(subtitle);
            v.subtitle.setTextColor(theme.onSurfaceVariant);

            // Permitir quitar cualquier canción (incluyendo las de Pomi Lo-Fi)
            v.defaultLabel.setVisibility(View.GONE);
            v.btnRemove.setVisibility(View.VISIBLE);
            ImageViewCompat.setImageTintList(v.btnRemove, ColorStateList.valueOf(theme.onSurfaceVariant));
            v.btnRemove.setOnClickListener(view -> listener.onRemoveTrack(track));
        }
    }

    @Override
    public int getItemCount() {
        return theme == null ? 0 : items.size();
    }

    static class HeaderHolder extends RecyclerView.ViewHolder {
        final TextView titleView;
        HeaderHolder(@NonNull View itemView) {
            super(itemView);
            titleView = itemView.findViewById(R.id.headerTitle);
        }
    }

    static class TrackHolder extends RecyclerView.ViewHolder {
        final ItemTrackBinding b;
        TrackHolder(ItemTrackBinding binding) {
            super(binding.getRoot());
            this.b = binding;
        }
    }
}
