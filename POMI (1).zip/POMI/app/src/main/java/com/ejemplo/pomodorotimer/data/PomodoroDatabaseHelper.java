package com.ejemplo.pomodorotimer.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class PomodoroDatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "pomodoro_stats.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_STATS = "stats";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_DATE = "date"; // Formato YYYY-MM-DD
    public static final String COLUMN_DURATION = "duration"; // en minutos
    public static final String COLUMN_TYPE = "type"; // "pomodoro" o "meta"

    public PomodoroDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_STATS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_DATE + " TEXT, "
                + COLUMN_DURATION + " INTEGER, "
                + COLUMN_TYPE + " TEXT" + ")";
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STATS);
        onCreate(db);
    }

    public boolean addRecord(String date, int duration, String type) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_DURATION, duration);
        values.put(COLUMN_TYPE, type);
        
        long result = db.insert(TABLE_STATS, null, values);
        db.close();
        return result != -1;
    }
}
