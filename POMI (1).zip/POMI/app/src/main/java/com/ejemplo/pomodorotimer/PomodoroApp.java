package com.ejemplo.pomodorotimer;

import android.app.Application;

import androidx.appcompat.app.AppCompatDelegate;

import com.ejemplo.pomodorotimer.data.ThemePreferences;
import com.ejemplo.pomodorotimer.notifications.PomodoroNotifier;
import com.ejemplo.pomodorotimer.ui.theme.AppTheme;

public class PomodoroApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        PomodoroNotifier.createChannel(this);

        // El modo claro/oscuro guardado se aplica antes de crear cualquier Activity,
        // así no hay un destello ni una recreación al abrir la app.
        AppCompatDelegate.setDefaultNightMode(
                AppTheme.nightModeFor(new ThemePreferences(this).getSettings().mode));
    }
}


