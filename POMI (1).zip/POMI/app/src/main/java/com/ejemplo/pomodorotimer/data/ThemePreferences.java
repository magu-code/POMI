package com.ejemplo.pomodorotimer.data;

import android.content.Context;
import android.content.SharedPreferences;

import com.ejemplo.pomodorotimer.model.ThemeMode;
import com.ejemplo.pomodorotimer.model.ThemeSettings;

public class ThemePreferences {

    private static final String FILE = "theme_prefs";
    private static final String PALETTE = "palette";
    private static final String MODE = "mode";

    private final SharedPreferences prefs;

    public ThemePreferences(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public ThemeSettings getSettings() {
        ThemeSettings defaults = new ThemeSettings();
        ThemeMode mode = defaults.mode;
        String modeName = prefs.getString(MODE, null);
        if (modeName != null) {
            for (ThemeMode m : ThemeMode.values()) {
                if (m.name().equals(modeName)) {
                    mode = m;
                    break;
                }
            }
        }
        return new ThemeSettings(prefs.getString(PALETTE, defaults.paletteId), mode);
    }

    public void setPalette(String id) {
        prefs.edit().putString(PALETTE, id).apply();
    }

    public void setMode(ThemeMode mode) {
        prefs.edit().putString(MODE, mode.name()).apply();
    }
}
