package com.ejemplo.pomodorotimer.model;

public enum ThemeMode {
    SYSTEM("Sistema"),
    LIGHT("Claro"),
    DARK("Oscuro");

    private final String label;

    ThemeMode(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
